'use strict';
// سازگاری برای اجرای Edge Functionهای Supabase (Deno) روی Node
const { webcrypto } = require('node:crypto');
if (!globalThis.crypto) globalThis.crypto = webcrypto;

const holder = { handler: null };
globalThis.Deno = {
  env: { get: (k) => process.env[k] },
  serve: (h) => { holder.handler = h; },
};

// درخواست‌های «سرور به سرور» به سرویس‌های هوش مصنوعی خارجی را در صورت تنظیم AI_RELAY از یک واسطه‌ی خارج از ایران عبور می‌دهد
const realFetch = globalThis.fetch;
const RELAY = (process.env.AI_RELAY || '').trim();
const RELAY_KEY = process.env.AI_RELAY_KEY || '';
const RELAY_HOSTS = /(^|\.)(googleapis\.com|api\.deepseek\.com|api\.perplexity\.ai|openai\.com|anthropic\.com|api\.resend\.com)$/i;
globalThis.fetch = function (input, init) {
  try {
    const url = typeof input === 'string' ? input : (input && input.url) || String(input);
    const u = new URL(url);
    if (RELAY && RELAY_HOSTS.test(u.hostname)) {
      const headers = Object.assign({}, (init && init.headers) || {});
      headers['x-relay-target'] = url;
      // پاسخ بدون فشرده‌سازی: سرویس‌های پشت CDN گاهی خروجی فشرده‌ی پخش زنده را بافر می‌کنند و پیام‌ها دیر یا یک‌جا می‌رسند
      for (const k of Object.keys(headers)) if (k.toLowerCase() === 'accept-encoding') delete headers[k];
      headers['accept-encoding'] = 'identity';
      headers['x-relay-key'] = RELAY_KEY;
      return realFetch(RELAY, Object.assign({}, init, { headers }));
    }
  } catch (e) { /* ادامه با fetch معمولی */ }
  return realFetch(input, init);
};

module.exports = {
  load(file) {
    holder.handler = null;
    delete require.cache[require.resolve(file)];
    require(file);
    if (typeof holder.handler !== 'function') throw new Error('no Deno.serve handler in ' + file);
    return holder.handler;
  },
};
