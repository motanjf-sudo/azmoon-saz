#!/usr/bin/env node
// ورود یک کتاب درسی (PDF) به پازمونک — بدون تبدیل به متن: هر صفحه به‌صورت عکس ذخیره می‌شود تا معلم (DeepSeek Vision) وقتی دانش‌آموز شماره‌ی صفحه را گفت همان عکس را ببیند.
// استفاده (از طریق bookingest.sh):
//   node ingest.js book.pdf --slug math7 --title "ریاضی هفتم" --grade هفتم --subject ریاضی --offset 9 --tocfile math7.toc.txt
'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const argv = process.argv.slice(2);
const file = argv[0];
const opt = (k, d) => { const i = argv.indexOf('--' + k); return i > 0 && argv[i + 1] !== undefined ? argv[i + 1] : d; };
const slug = opt('slug', '');
const title = opt('title', '');
const grade = opt('grade', '');
const subject = opt('subject', '');
const offset = parseInt(opt('offset', '0'), 10) || 0;          // شماره‌ی چاپی = شماره‌ی صفحه‌ی PDF − ۱ − offset
const tocfile = opt('tocfile', '');
const WIDTH = parseInt(opt('width', '1000'), 10) || 1000;
const BOOKS = (process.env.BOOKS_DIR || '/var/lib/pazmoonak-books').replace(/\/+$/, '');
const SERVICE_KEY = process.env.SERVICE_KEY || '';
const API = (process.env.API_URL || 'http://127.0.0.1:' + (process.env.PORT || '8787')).replace(/\/+$/, '');

function die(m) { console.error('❌ ' + m); process.exit(1); }
if (!file || !fs.existsSync(file)) die('فایل PDF پیدا نشد: ' + file);
if (!/^[a-z0-9_-]{1,40}$/.test(slug)) die('--slug باید فقط حرف انگلیسی کوچک، عدد، - یا _ باشد (مثلاً math7).');
if (!title) die('--title لازم است.');
if (!SERVICE_KEY) die('SERVICE_KEY در تنظیمات سرور پیدا نشد.');

async function rpc(name, args) {
  const r = await fetch(API + '/rest/v1/rpc/' + name, {
    method: 'POST',
    headers: { 'content-type': 'application/json', apikey: SERVICE_KEY, authorization: 'Bearer ' + SERVICE_KEY },
    body: JSON.stringify(args),
    signal: AbortSignal.timeout(30000),
  });
  const t = await r.text();
  if (!r.ok) throw new Error('rpc ' + name + ' ' + r.status + ' ' + t.slice(0, 200));
  return t ? JSON.parse(t) : null;
}

async function main() {
  const dir = path.join(BOOKS, slug);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = fs.mkdtempSync(path.join(dir, '.tmp-'));
  console.log('در حال تبدیل صفحه‌های PDF به عکس...');
  const rr = cp.spawnSync('pdftoppm', ['-scale-to-x', String(WIDTH), '-scale-to-y', '-1', '-jpeg', '-jpegopt', 'quality=80', file, path.join(tmp, 'p')], { encoding: 'utf8' });
  if (rr.error || rr.status !== 0) die('pdftoppm اجرا نشد: ' + ((rr.error && rr.error.message) || rr.stderr || '').slice(0, 200));
  const imgs = fs.readdirSync(tmp).filter((f) => /^p-\d+\.jpg$/.test(f));
  if (!imgs.length) die('هیچ صفحه‌ای تبدیل نشد.');
  let saved = 0, last = 0;
  for (const f of imgs) {
    const n = parseInt(f.slice(2, -4), 10);
    const printed = n - 1 - offset;
    if (printed < 1) continue;                                   // جلد و صفحه‌های اول (بدون شماره‌ی چاپی)
    fs.renameSync(path.join(tmp, f), path.join(dir, printed + '.jpg'));
    saved++; if (printed > last) last = printed;
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  let toc = '';
  if (tocfile) { try { toc = fs.readFileSync(tocfile, 'utf8').trim().slice(0, 6000); } catch (e) { console.log('⚠️ فایل فهرست خوانده نشد: ' + tocfile); } }
  await rpc('book_upsert', { p_slug: slug, p_title: title, p_grade: grade, p_subject: subject, p_toc: toc });
  try { cp.spawnSync('chmod', ['-R', 'a+rX', BOOKS]); } catch (e) { /* ignore */ }
  console.log('تمام شد: عکس ' + saved + ' صفحه (صفحه‌ی ۱ تا ' + last + ') در ' + dir + ' ذخیره شد' + (toc ? ' | فهرست ذخیره شد' : ' | بدون فهرست') + '.');
}
main().catch((e) => die(String(e && e.stack || e).slice(0, 400)));
