'use strict';
/*
 * بک‌اند پازمونک (جایگزین Supabase روی سرور ایرانی)
 *  - POST /rest/v1/rpc/<تابع>      → اجرای تابع‌های PostgreSQL (مثل PostgREST)
 *  - POST /functions/v1/auth-otp   → ثبت‌نام و ورود با پیامک
 *  - POST /functions/v1/node-api   → ساخت آزمون با هوش مصنوعی
 *  - POST/GET /functions/v1/pay    → خرید توکن با درگاه زیبال (شروع، برگشت از بانک، وضعیت)
 *  - POST /functions/v1/tutor      → معلم هوشمند (گفت‌وگوی درسی؛ فقط وقتی TUTOR_ENABLED=1)
 *  - GET  /healthz                 → بررسی سلامت
 */
const http = require('node:http');
const crypto = require('node:crypto');
const path = require('node:path');
const { Pool } = require('pg');
const shim = require('./deno-shim.js');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const SERVICE_KEY = process.env.SERVICE_KEY || '';
const MAX_BODY = 12 * 1024 * 1024;

if (!process.env.DATABASE_URL) { console.error('DATABASE_URL تنظیم نشده است'); process.exit(1); }
if (SERVICE_KEY.length < 32) { console.error('SERVICE_KEY باید حداقل ۳۲ نویسه باشد'); process.exit(1); }

// توابع Edge از طریق همین سرور به دیتابیس می‌رسند (مثل Supabase)
process.env.SUPABASE_URL = `http://127.0.0.1:${PORT}`;
process.env.SUPABASE_SERVICE_ROLE_KEY = SERVICE_KEY;

// کلید حساب سرویس گوگل (فایل JSON) از فایل جدا خوانده می‌شود تا در فایل env مشکل نقل‌قول و چندخطی پیش نیاید
if (!process.env.GOOGLE_SERVICE_ACCOUNT_JSON) {
  try {
    const f = process.env.GOOGLE_SA_FILE || '/etc/pazmoonak/google-sa.json';
    if (require('fs').existsSync(f)) process.env.GOOGLE_SERVICE_ACCOUNT_JSON = require('fs').readFileSync(f, 'utf8');
  } catch (e) { console.error('خواندن فایل حساب سرویس گوگل ناموفق بود:', e.message); }
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  statement_timeout: 15000,
});
pool.on('error', (e) => console.error('pg pool error:', e.message));

const CORS = {
  'X-Content-Type-Options': 'nosniff',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, prefer',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

function send(res, status, obj, extra) {
  const body = obj === undefined ? '' : JSON.stringify(obj);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, CORS, extra || {}));
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function keyOf(req) {
  const a = String(req.headers['authorization'] || '');
  const m = /^Bearer\s+(.+)$/i.exec(a);
  return (m && m[1].trim()) || String(req.headers['apikey'] || '').trim();
}
function isService(req) {
  const k = Buffer.from(keyOf(req));
  const s = Buffer.from(SERVICE_KEY);
  return k.length === s.length && crypto.timingSafeEqual(k, s);
}

// ---- RPC ----
const sigCache = new Map();
async function getSig(name) {
  if (sigCache.has(name)) return sigCache.get(name);
  const r = await pool.query(
    `select p.proargnames as names,
            array(select format_type(t, null) from unnest(p.proargtypes) t) as types
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public' and p.proname = $1`, [name]);
  const sig = r.rows.length === 1 ? r.rows[0] : null;
  if (sig) sigCache.set(name, sig);
  return sig;
}

async function callRpc(role, name, args) {
  if (!/^[a-z_][a-z0-9_]*$/.test(name)) return { status: 404, body: { message: 'تابع پیدا نشد.' } };
  const sig = await getSig(name);
  if (!sig) return { status: 404, body: { code: 'PGRST202', message: 'تابع پیدا نشد.' } };
  const names = sig.names || [];
  const params = []; const parts = [];
  for (const k of Object.keys(args || {})) {
    const i = names.indexOf(k);
    if (i < 0) return { status: 404, body: { code: 'PGRST202', message: 'پارامتر ناشناخته: ' + k } };
    const type = sig.types[i];
    let v = args[k];
    if (v !== null && v !== undefined && (type === 'jsonb' || type === 'json')) v = JSON.stringify(v);
    params.push(v === undefined ? null : v);
    parts.push(`"${k}" := $${params.length}::${type}`);
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`SET LOCAL ROLE ${role === 'service_role' ? 'service_role' : 'anon'}`);
    const r = await client.query(`select public."${name}"(${parts.join(', ')}) as r`, params);
    await client.query('COMMIT');
    return { status: 200, body: r.rows[0] ? r.rows[0].r : null };
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch (_) { /* ignore */ }
    const code = e.code || '';
    if (code === '42501') return { status: 401, body: { code, message: 'دسترسی مجاز نیست.' } };
    if (code === 'P0001' || /^(22|23|42)/.test(code)) return { status: 400, body: { code, message: e.message } };
    console.error('rpc error', name, code, e.message);
    return { status: 500, body: { message: 'خطای سرور.' } };
  } finally {
    client.release();
  }
}

// ---- Edge functions ----
const handlers = {};
function fnHandler(name) {
  if (!handlers[name]) handlers[name] = shim.load(path.join(__dirname, 'fn', name + '.js'));
  return handlers[name];
}
const FN_ROUTES = { 'auth-otp': 'auth-otp', 'node-api': 'node-api', 'generate-quiz': 'node-api', 'tutor': 'tutor', 'pay': 'pay' };

async function runFunction(req, res, name, bodyBuf) {
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
  const request = new Request('http://localhost' + req.url, { method: req.method, headers, body: req.method === 'GET' ? undefined : bodyBuf });
  const response = await fnHandler(name)(request);
  const h = {};
  response.headers.forEach((v, k) => { h[k] = v; });
  if (response.body && String(h['content-type'] || '').startsWith('text/event-stream')) {
    // پاسخ زنده (استریم): تکه‌تکه و بدون بافر برای مرورگر فرستاده می‌شود
    res.writeHead(response.status, h);
    res.flushHeaders();
    if (res.socket) res.socket.setNoDelay(true);
    const reader = response.body.getReader();
    let gone = false;
    res.on('close', () => { gone = true; reader.cancel().catch(() => {}); });
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done || gone) break;
        res.write(Buffer.from(value));
      }
    } catch (e) { /* قطع شدن اتصال */ }
    return res.end();
  }
  const out = Buffer.from(await response.arrayBuffer());
  res.writeHead(response.status, h);
  res.end(out);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const p = url.pathname.replace(/\/+$/, '') || '/';

    if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
    if (p === '/healthz') {
      await pool.query('select 1');
      return send(res, 200, { ok: true });
    }

    let m = /^\/rest\/v1\/rpc\/([A-Za-z0-9_]+)$/.exec(p);
    if (m) {
      if (req.method !== 'POST') return send(res, 405, { message: 'روش نامعتبر.' });
      const buf = await readBody(req);
      let args = {};
      try { args = buf.length ? JSON.parse(buf.toString('utf8')) : {}; } catch (_) { return send(res, 400, { message: 'JSON نامعتبر.' }); }
      if (args === null || typeof args !== 'object' || Array.isArray(args)) return send(res, 400, { message: 'JSON نامعتبر.' });
      const r = await callRpc(isService(req) ? 'service_role' : 'anon', m[1], args);
      return send(res, r.status, r.body);
    }

    m = /^\/functions\/v1\/([a-z-]+)$/.exec(p);
    /* معلم هوشمند فعلاً خاموش است (از سایت پنهان شده)؛ برای روشن‌کردن دوباره در فایل env بنویسید TUTOR_ENABLED=1 */
    if (m && m[1] === 'tutor' && process.env.TUTOR_ENABLED !== '1') return send(res, 404, { message: 'پیدا نشد.' });
    if (m && FN_ROUTES[m[1]]) {
      const buf = req.method === 'GET' ? Buffer.alloc(0) : await readBody(req);
      return await runFunction(req, res, FN_ROUTES[m[1]], buf);
    }

    send(res, 404, { message: 'پیدا نشد.' });
  } catch (e) {
    if (e && e.status === 413) return send(res, 413, { message: 'حجم درخواست زیاد است.' });
    console.error('server error:', e && e.message);
    if (!res.headersSent) send(res, 500, { message: 'خطای سرور.' }); else res.end();
  }
});
server.requestTimeout = 300000;
server.headersTimeout = 30000;
server.listen(PORT, HOST, () => console.log(`pazmoonak api on ${HOST}:${PORT}`));

// بررسی پس‌زمینه‌ی پرداخت‌ها: اگر کاربر بعد از پرداخت صفحه را بسته یا برگشت از بانک به سرور نرسیده باشد، هر ۳ دقیقه
// سفارش‌های نیمه‌کاره از زیبال پرسیده می‌شوند و اگر پرداخت شده بودند، توکن اضافه می‌شود (فقط وقتی ZIBAL_MERCHANT تنظیم باشد)
let reconciling = false;
async function reconcilePayments() {
  if (reconciling || !process.env.ZIBAL_MERCHANT) return;
  reconciling = true;
  try {
    const request = new Request('http://localhost/functions/v1/pay', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + SERVICE_KEY },
      body: JSON.stringify({ action: 'reconcile' }),
    });
    const r = await fnHandler('pay')(request);
    const t = await r.text();
    if (r.status !== 200) console.error('payment reconcile failed', r.status, t.slice(0, 200));
    else { try { const j = JSON.parse(t); if (j.paid) console.log('payment reconcile: credited', j.paid); } catch (_) { /* ignore */ } }
  } catch (e) { console.error('payment reconcile error:', e && e.message); }
  finally { reconciling = false; }
}
setInterval(reconcilePayments, 3 * 60 * 1000).unref();
setTimeout(reconcilePayments, 20 * 1000).unref();

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { server.close(() => pool.end().then(() => process.exit(0))); setTimeout(() => process.exit(0), 5000).unref(); });
