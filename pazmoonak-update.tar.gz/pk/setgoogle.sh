#!/usr/bin/env bash
# ذخیره‌ی کد JSON حساب سرویس گوگل (برای جمینی). با root اجرا شود:  bash setgoogle.sh
set -euo pipefail
F=/etc/pazmoonak/google-sa.json
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
[ -d /etc/pazmoonak ] || { echo "پوشه‌ی تنظیمات پیدا نشد."; exit 1; }
echo "کل محتوای فایل JSON گوگل را بچسبانید (از { تا }). بعد Enter بزنید و بعد همزمان Ctrl و D را فشار دهید:"
TMP="$(mktemp)"; chmod 600 "$TMP"
cat > "$TMP"
if ! node -e 'const j=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));if(!(j.client_email&&j.private_key&&j.project_id))process.exit(2);console.log("پروژه:",j.project_id)' "$TMP"; then
  rm -f "$TMP"; echo "❌ این JSON درست نیست (یا ناقص چسبانده شده). تغییری داده نشد."; exit 1
fi
cat "$TMP" > "$F"; rm -f "$TMP"
chown root:pazmoonak "$F"; chmod 640 "$F"
systemctl restart pazmoonak; sleep 2
echo "ذخیره شد و سرویس دوباره راه‌اندازی شد ✅"
