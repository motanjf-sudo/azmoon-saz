#!/usr/bin/env bash
# به‌روزرسانی بک‌اند پازمونک (بدون دست‌زدن به داده‌ها، رمزها و تنظیمات). با root اجرا شود:  bash update.sh
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
APP=/opt/pazmoonak
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
echo "== [1/3] کپی فایل‌های برنامه"
rm -rf "$APP/fn"
[ -f "$SRC/server.js" ] && cp "$SRC/server.js" "$APP/"
[ -f "$SRC/deno-shim.js" ] && cp "$SRC/deno-shim.js" "$APP/"
[ -f "$SRC/ingest.js" ] && cp "$SRC/ingest.js" "$APP/"
cp -r "$SRC/fn" "$APP/"
chown -R root:pazmoonak "$APP"
chmod -R g+rX,o-rwx "$APP"
echo "== [2/3] به‌روزرسانی دیتابیس"
mkdir -p /tmp/pz && cp "$SRC/db/schema.sql" /tmp/pz/ && chmod -R a+rX /tmp/pz
su postgres -c "psql -q -v ON_ERROR_STOP=1 -d pazmoonak -f /tmp/pz/schema.sql" 2>&1 | grep -v NOTICE || true
rm -rf /tmp/pz
[ -f "$SRC/front-sync.sh" ] && install -m 755 "$SRC/front-sync.sh" /usr/local/bin/pz-front
echo "== [3/3] راه‌اندازی دوباره"
systemctl restart pazmoonak
sleep 2
curl -fsS http://127.0.0.1:8787/healthz && echo
# بررسی درگاه پرداخت (خروجی انگلیسی تا در کنسول درست نمایش داده شود)
if grep -q '^ZIBAL_MERCHANT=.' /etc/pazmoonak/env 2>/dev/null; then echo "ZIBAL key: OK"; else echo "ZIBAL key: MISSING (run: bash setkey.sh ZIBAL_MERCHANT)"; fi
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST -H 'content-type: application/json' -d '{"action":"x"}' http://127.0.0.1:8787/functions/v1/pay || true)
if [ "$code" = "401" ]; then echo "pay route: OK"; else echo "pay route: PROBLEM (http $code)"; fi
echo "تمام شد ✅"
