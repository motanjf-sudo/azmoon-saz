#!/usr/bin/env bash
# ورود یک کتاب درسی به پازمونک (عکس صفحه‌ها). با root اجرا شود. مثال:
#   bash bookingest.sh /root/math7.pdf math7 "ریاضی هفتم" هفتم ریاضی 9 /root/pk/books/math7.toc.txt
# آرگومان‌ها: فایل-PDF  نام-لاتین  عنوان  پایه  درس  فاصله‌ی-شماره-صفحه  فایل-فهرست(اختیاری)
set -uo pipefail
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
[ $# -ge 5 ] || { echo "استفاده: bash bookingest.sh فایل.pdf نام-لاتین \"عنوان\" پایه درس [offset] [فایل-فهرست]"; exit 1; }
PDF="$1"; SLUG="$2"; TITLE="$3"; GRADE="$4"; SUBJ="$5"; OFF="${6:-0}"; TOC="${7:-}"
if ! command -v pdftoppm >/dev/null; then
  echo "نصب ابزار تبدیل PDF (یک‌بار)..."
  apt-get install -y poppler-utils >/dev/null 2>&1 || { echo "نصب poppler-utils ناموفق بود."; exit 1; }
fi
set -a; . /etc/pazmoonak/env; set +a
cd /opt/pazmoonak || exit 1
ARGS=(--slug "$SLUG" --title "$TITLE" --grade "$GRADE" --subject "$SUBJ" --offset "$OFF")
[ -n "$TOC" ] && ARGS+=(--tocfile "$TOC")
exec node /opt/pazmoonak/ingest.js "$PDF" "${ARGS[@]}"
