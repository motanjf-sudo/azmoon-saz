#!/usr/bin/env bash
# آخرین نسخه‌ی سایت را از GitHub می‌گیرد و جایگزین فایل‌های سایت می‌کند:  pz-front
set -euo pipefail
REPO=motanjf-sudo/azmoon-saz
BRANCH=main
WEB=/var/www/pazmoonak
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
echo "دریافت آخرین نسخه از GitHub ..."
wget -q -T 40 -t 3 -O "$T/s.tgz" "https://codeload.github.com/${REPO}/tar.gz/refs/heads/${BRANCH}" || { echo "خطا: دانلود از GitHub انجام نشد. سایت دست‌نخورده ماند."; exit 1; }
tar xzf "$T/s.tgz" -C "$T"
D=$(ls -d "$T"/*/ | head -1)
for f in index.html app.js config.js; do
  [ -s "$D$f" ] || { echo "خطا: فایل $f در نسخه‌ی دریافت‌شده نیست. سایت دست‌نخورده ماند."; exit 1; }
done
mkdir -p "$WEB"
put() { install -m 644 "$D$1" "$WEB/$1.new" && mv -f "$WEB/$1.new" "$WEB/$1"; }
for f in katex-bundle.js app.js config.js style.css robots.txt sitemap.xml; do [ -f "$D$f" ] && put "$f"; done
if [ -d "$D/logo" ]; then mkdir -p "$WEB/logo" && cp -f "$D"logo/* "$WEB/logo/" && chmod 644 "$WEB"/logo/*; fi
put index.html
echo "سایت به‌روز شد ✅  ($(du -sh "$WEB" | cut -f1))"
