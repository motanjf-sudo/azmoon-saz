#!/usr/bin/env bash
# آزمایش کامل پخش زنده از مسیر سرور ← Cloudflare ← مدل‌ها. با root اجرا شود:  bash teststream.sh
# هر خط: طولانی‌ترین مکث بین دو تکه‌ی رسیده و محل آن، تا معلوم شود قطعی به فشرده‌سازی، مارکداون، یا خود مسیر ربط دارد.
set -uo pipefail
ENV_FILE=/etc/pazmoonak/env
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
g() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -1; }
export RELAY="$(g AI_RELAY)" RKEY="$(g AI_RELAY_KEY)" DKEY="$(g DEEPSEEK_API_KEY)" PKEY="$(g PERPLEXITY_API_KEY)" GPROJ="$(g GOOGLE_PROJECT)"
[ -n "$RELAY" ] || { echo "تنظیمات ناقص است."; exit 1; }
command -v python3 >/dev/null || { echo "python3 نصب نیست."; exit 1; }
echo "در حال آزمایش؛ حدود ۳ تا ۵ دقیقه طول می‌کشد. تا پایان صبر کنید..."
python3 - <<'PY'
import os, json, time, zlib, urllib.request
R, RK = os.environ["RELAY"], os.environ["RKEY"]
BOLD = "درباره‌ی توان در ریاضی هفتم توضیح بده. حتماً کلمه‌های کلیدی را با ** پررنگ کن، لیست و فرمول هم بگذار."
PLAIN = "درباره‌ی توان در ریاضی هفتم توضیح بده. فقط متن ساده بنویس و هیچ علامت ستاره یا مارکداونی استفاده نکن."
def run(name, target, headers, body, enc, parse):
    h = {"content-type": "application/json", "x-relay-target": target, "x-relay-key": RK, "accept-encoding": enc}
    h.update(headers)
    req = urllib.request.Request(R, data=json.dumps(body).encode(), method="POST", headers=h)
    t0 = last = time.time(); mx = 0.0; at = 0; txt = ""; res = "ok"; ce = "-"; n = 0
    try:
        r = urllib.request.urlopen(req, timeout=45)
        ce = r.headers.get("content-encoding") or "-"
        dz = zlib.decompressobj(16 + zlib.MAX_WBITS) if ce == "gzip" else None
        buf = b""
        while True:
            c = r.read1(8192)
            if not c: break
            now = time.time(); g = now - last; last = now; n += 1
            if g > mx: mx = g; at = len(txt)
            buf += dz.decompress(c) if dz else c
            while b"\n" in buf:
                ln, buf = buf.split(b"\n", 1)
                ln = ln.decode("utf8", "ignore").strip()
                if ln.startswith("data:") and ln[5:].strip() not in ("", "[DONE]"):
                    try: txt += parse(json.loads(ln[5:]))
                    except Exception: pass
    except Exception as e:
        res = "خطا/قطع: " + str(e)[:50]
    flag = "  ⚠️ مکث طولانی" if mx > 5 else ""
    print("%-34s حرف=%4d کل=%5.1fث بسته=%3d مکث=%5.1fث (در حرف %d) ** =%d فشرده=%s %s%s" % (name, len(txt), time.time() - t0, n, mx, at, txt.count("**"), ce, res, flag), flush=True)
ds = lambda j: j["choices"][0]["delta"].get("content") or ""
def dsbody(p): return {"model": "deepseek-chat", "stream": True, "max_tokens": 700, "messages": [{"role": "user", "content": p}]}
if os.environ.get("DKEY"):
    H = {"authorization": "Bearer " + os.environ["DKEY"]}
    for i in range(2):
        for enc, en in (("gzip, deflate", "gzip"), ("identity", "بدون‌فشرده")):
            for pn, p in (("پررنگ", BOLD), ("ساده", PLAIN)):
                run("DeepSeek %s %s #%d" % (en, pn, i + 1), "https://api.deepseek.com/chat/completions", H, dsbody(p), enc, ds)
if os.environ.get("PKEY"):
    pp = lambda j: j["delta"] if "output_text.delta" in str(j.get("type")) and isinstance(j.get("delta"), str) else ""
    for i in range(2):
        for enc, en in (("gzip, deflate", "gzip"), ("identity", "بدون‌فشرده")):
            run("Perplexity %s پررنگ #%d" % (en, i + 1), "https://api.perplexity.ai/v1/agent", {"authorization": "Bearer " + os.environ["PKEY"]}, {"model": "anthropic/claude-haiku-5-5", "instructions": "پاسخ فارسی بده.", "input": [{"role": "user", "content": BOLD}], "max_output_tokens": 700, "stream": True}, enc, pp)
if os.environ.get("GPROJ"):
    gm = lambda j: "".join(x.get("text", "") for x in (j.get("candidates") or [{}])[0].get("content", {}).get("parts", []))
    for i in range(2):
        run("Gemini (مقایسه) #%d" % (i + 1), "https://aiplatform.googleapis.com/v1/projects/%s/locations/global/publishers/google/models/gemini-2.5-flash:streamGenerateContent?alt=sse" % os.environ["GPROJ"], {"x-relay-gauth": "1"}, {"contents": [{"role": "user", "parts": [{"text": BOLD}]}], "generationConfig": {"maxOutputTokens": 700}}, "gzip, deflate", gm)
print("پایان.")
PY
