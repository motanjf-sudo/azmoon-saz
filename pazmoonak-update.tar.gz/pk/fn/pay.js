const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
};
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, "Content-Type": "application/json", "Cache-Control": "no-store" } });
const env = (k, d = "") => (Deno.env.get(k) || d).trim();
const zibalBase = () => env("ZIBAL_BASE", "https://gateway.zibal.ir").replace(/\/$/, "");
const apiUrl = () => env("PUBLIC_API_URL", "https://api.pazmoonak.com").replace(/\/$/, "");
const siteUrl = () => env("PUBLIC_SITE_URL", "https://pazmoonak.com").replace(/\/$/, "");
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const redirect = (to) => new Response(null, { status: 302, headers: { ...CORS, Location: to, "Cache-Control": "no-store" } });
async function dbRpc(name, args) {
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  const r = await fetch((Deno.env.get("SUPABASE_URL") || "").replace(/\/$/, "") + "/rest/v1/rpc/" + name, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: key, Authorization: "Bearer " + key },
    body: JSON.stringify(args)
  });
  if (!r.ok) throw new Error(name + " HTTP " + r.status);
  return await r.json();
}
async function zibal(path, body) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 2e4);
  try {
    const r = await fetch(zibalBase() + "/v1/" + path, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body),
      signal: ctl.signal
    });
    const t = await r.text();
    try {
      return JSON.parse(t);
    } catch {
      console.error("zibal " + path + " bad body", r.status, t.slice(0, 200));
      return null;
    }
  } catch (e) {
    console.error("zibal " + path + " failed", String(e));
    return null;
  } finally {
    clearTimeout(timer);
  }
}
async function settle(p) {
  if (!p) return { status: "failed" };
  if (p.status === "paid") return { status: "paid" };
  if (p.status === "review") return { status: "review" };
  const merchant = env("ZIBAL_MERCHANT");
  if (!merchant || !p.track_id) return { status: p.status === "failed" ? "failed" : "pending" };
  const trackId = Number(p.track_id);
  let info = null;
  const v = await zibal("verify", { merchant, trackId });
  if (!v) return { status: p.status === "failed" ? "failed" : "pending" };
  if (v.result === 100 && v.amount != null) {
    info = v;
  } else if (v.result === 100 || v.result === 201) {
    const q = await zibal("inquiry", { merchant, trackId });
    if (!q) return { status: p.status === "failed" ? "failed" : "pending" };
    if (q.status === 1) info = { ...q, amount: q.amount != null ? q.amount : Number(p.amount_toman) * 10 };
  } else {
    if (v.result !== 202) console.error("zibal verify unexpected", p.id, JSON.stringify(v).slice(0, 300));
    const q = await zibal("inquiry", { merchant, trackId });
    if (q && typeof q.status === "number" && q.status >= 3 && q.status <= 12 && p.status === "pending") {
      try {
        await dbRpc("pay_fail", { p_id: p.id, p_note: "zibal status " + q.status });
      } catch (e) {
        console.error("pay_fail", String(e));
      }
      return { status: "failed" };
    }
    return { status: p.status === "failed" ? "failed" : "pending" };
  }
  if (!info) return { status: p.status === "failed" ? "failed" : "pending" };
  if (info.orderId != null && String(info.orderId) !== String(p.id)) {
    console.error("zibal orderId mismatch", p.id, String(info.orderId));
    return { status: "pending" };
  }
  const r = await dbRpc("pay_credit", { p_id: p.id, p_amount_rial: Number(info.amount), p_ref: String(info.refNumber ?? "") });
  if (r?.ok) return { status: "paid" };
  console.error("pay_credit refused", p.id, JSON.stringify(r), String(info.amount));
  return { status: r?.error === "mismatch" ? "review" : "pending" };
}
async function handle(req) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method === "GET") {
    const u = new URL(req.url);
    const site = siteUrl();
    const order = String(u.searchParams.get("orderId") || "");
    if (!UUID.test(order)) return redirect(site + "/tokens?pay=0");
    try {
      const p = await dbRpc("pay_get", { p_id: order });
      if (!p) return redirect(site + "/tokens?pay=0");
      await settle(p);
      return redirect(site + "/tokens?pay=1&o=" + encodeURIComponent(order));
    } catch (e) {
      console.error("pay callback error", order, String(e));
      return redirect(site + "/tokens?pay=2&o=" + encodeURIComponent(order));
    }
  }
  if (req.method !== "POST") return json({ error: "\u0631\u0648\u0634 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 405);
  let b;
  try {
    b = await req.json();
  } catch {
    return json({ error: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 400);
  }
  const action = String(b?.action || "");
  if (action === "reconcile") {
    const m = /^Bearer\s+(.+)$/i.exec(req.headers.get("authorization") || "");
    const svc = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    if (!m || !svc || m[1].trim() !== svc) return json({ error: "forbidden" }, 403);
    const due = await dbRpc("pay_due", { p_limit: 20 });
    let paid = 0;
    for (const p of due) {
      const s = await settle(p);
      if (s.status === "paid") paid++;
    }
    return json({ checked: due.length, paid });
  }
  const token = String(b?.token || "");
  if (!/^[0-9a-f]{64}$/i.test(token)) return json({ error: "\u0628\u0631\u0627\u06CC \u062E\u0631\u06CC\u062F \u0628\u0627\u06CC\u062F \u0648\u0627\u0631\u062F \u062D\u0633\u0627\u0628 \u0634\u0648\u06CC\u062F." }, 401);
  if (action === "start") {
    const merchant = env("ZIBAL_MERCHANT");
    if (!merchant) return json({ error: "not_configured" }, 503);
    const count = Math.floor(Number(b?.tokens));
    if (!Number.isFinite(count) || count < 10 || count > 1e4) return json({ error: "\u062A\u0639\u062F\u0627\u062F \u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 400);
    const expect = typeof b?.expect === "number" && Number.isFinite(b.expect) ? Math.floor(b.expect) : null;
    const rs = await dbRpc("pay_create", { p_token: token, p_tokens: count, p_expect: expect });
    if (!rs?.ok) {
      if (rs?.error === "no_session") return json({ error: "\u0628\u0631\u0627\u06CC \u062E\u0631\u06CC\u062F \u0628\u0627\u06CC\u062F \u0648\u0627\u0631\u062F \u062D\u0633\u0627\u0628 \u0634\u0648\u06CC\u062F." }, 401);
      if (rs?.error === "price_changed") return json({ error: "price_changed", amount: rs.amount }, 409);
      if (rs?.error === "too_many") return json({ error: "\u0686\u0646\u062F \u067E\u0631\u062F\u0627\u062E\u062A \u0646\u06CC\u0645\u0647\u200C\u06A9\u0627\u0631\u0647 \u062F\u0627\u0631\u06CC\u062F. \u0686\u0646\u062F \u062F\u0642\u06CC\u0642\u0647 \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F." }, 429);
      return json({ error: "\u062A\u0639\u062F\u0627\u062F \u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 400);
    }
    const z = await zibal("request", {
      merchant,
      amount: Number(rs.amount) * 10,
      // زیبال ریال می‌گیرد
      callbackUrl: apiUrl() + "/functions/v1/pay",
      orderId: String(rs.id),
      description: "\u062E\u0631\u06CC\u062F " + count + " \u062A\u0648\u06A9\u0646 \u067E\u0627\u0632\u0645\u0648\u0646\u06A9"
    });
    if (!z || z.result !== 100 || !z.trackId) {
      console.error("zibal request failed", JSON.stringify(z || null).slice(0, 300));
      try {
        await dbRpc("pay_fail", { p_id: rs.id, p_note: "request failed " + (z ? z.result : "no response") });
      } catch (_) {
      }
      return json({ error: "\u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u062F\u0631\u06AF\u0627\u0647 \u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u0634\u062F. \u06A9\u0645\u06CC \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F." }, 502);
    }
    await dbRpc("pay_attach", { p_id: rs.id, p_track: Number(z.trackId) });
    return json({ ok: true, url: zibalBase() + "/start/" + z.trackId, order: rs.id, amount: rs.amount });
  }
  if (action === "status") {
    const order = String(b?.order || "");
    if (!UUID.test(order)) return json({ error: "\u0633\u0641\u0627\u0631\u0634 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 400);
    let p = await dbRpc("pay_owner_get", { p_token: token, p_id: order });
    if (!p) return json({ error: "\u0633\u0641\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F." }, 404);
    if (p.status !== "paid" && p.status !== "review") {
      await settle(p);
      p = await dbRpc("pay_owner_get", { p_token: token, p_id: order });
    }
    return json({ status: p.status, tokens: p.tokens, amount: p.amount_toman, ref: p.ref_number || "", balance: p.balance });
  }
  if (action === "check") {
    const list = await dbRpc("pay_pending_of", { p_token: token });
    let credited = 0, pending = 0, balance = null;
    for (const p of list) {
      const s = await settle(p);
      if (s.status === "paid") credited += Number(p.tokens);
      else if (s.status === "pending") pending++;
    }
    if (list.length) {
      const last = await dbRpc("pay_owner_get", { p_token: token, p_id: list[0].id });
      if (last) balance = last.balance;
    }
    return json({ credited, pending, balance });
  }
  return json({ error: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." }, 400);
}
Deno.serve(async (req) => {
  try {
    return await handle(req);
  } catch (e) {
    console.error("pay error", String(e));
    return json({ error: "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F." }, 500);
  }
});
