-- آزمون‌ساز: ساختار پایگاه‌داده
-- این فایل را در Supabase > SQL Editor اجرا کنید.
-- چندبار اجرا کردنش بی‌خطر است (اگر قبلاً اجرا کرده‌اید، فقط تابع‌ها به‌روز می‌شوند و داده‌ها پاک نمی‌شوند).
--
-- نوع سؤال‌ها (فیلد type در هر سؤال):
--   mcq   : چندگزینه‌ای (۲ تا ۸ گزینه)
--   tf    : درست/نادرست (دقیقاً ۲ گزینه)
-- آزمون‌های قدیمی که type ندارند، چندگزینه‌ای حساب می‌شوند.

create table if not exists public.quizzes (
  id          text primary key,
  title       text not null check (char_length(title) between 1 and 200),
  description text not null default '' check (char_length(description) <= 2000),
  questions   jsonb not null,            -- [{ "type":"mcq", "text":"...", "options":["..",".."], "correct":0 }]
  admin_hash  text not null,             -- هش SHA-256 کلید مدیریت
  created_at  timestamptz not null default now()
);

create table if not exists public.submissions (
  id         bigserial primary key,
  quiz_id    text not null references public.quizzes(id) on delete cascade,
  name       text not null check (char_length(name) between 1 and 100),
  answers    jsonb not null,
  score      int not null,
  total      int not null,
  created_at timestamptz not null default now()
);

create index if not exists submissions_quiz_idx on public.submissions(quiz_id);

-- دسترسی مستقیم به جدول‌ها بسته است؛ فقط از طریق تابع‌های پایین.
alter table public.quizzes     enable row level security;
alter table public.submissions enable row level security;

-- بررسی سؤال‌ها (مشترک بین ساخت و ویرایش)
create or replace function public.validate_questions(p_questions jsonb)
returns void
language plpgsql set search_path = public as $$
declare
  q jsonb;
  qtype text;
  n int;
begin
  if p_questions is null or jsonb_typeof(p_questions) <> 'array' or jsonb_array_length(p_questions) = 0
     or jsonb_array_length(p_questions) > 100 then
    raise exception 'تعداد سؤال‌ها نامعتبر است';
  end if;
  for q in select * from jsonb_array_elements(p_questions) loop
    if jsonb_typeof(q) <> 'object' then
      raise exception 'یکی از سؤال‌ها نامعتبر است';
    end if;
    qtype := coalesce(q->>'type', 'mcq');
    if qtype not in ('mcq', 'tf') then
      raise exception 'نوع سؤال نامعتبر است';
    end if;
    if jsonb_typeof(q->'text') <> 'string' or char_length(trim(q->>'text')) = 0
       or char_length(q->>'text') > 500 then
      raise exception 'متن یکی از سؤال‌ها نامعتبر است';
    end if;
    if jsonb_typeof(q->'options') <> 'array' then
      raise exception 'گزینه‌های یکی از سؤال‌ها نامعتبر است';
    end if;
    n := jsonb_array_length(q->'options');
    if n < 2 or n > 8 then
      raise exception 'تعداد گزینه‌های یکی از سؤال‌ها نامعتبر است';
    end if;
    if exists (
      select 1 from jsonb_array_elements(q->'options') o
      where jsonb_typeof(o) <> 'string' or char_length(trim(o #>> '{}')) = 0 or char_length(o #>> '{}') > 300
    ) then
      raise exception 'گزینه‌ی یکی از سؤال‌ها نامعتبر است';
    end if;
    if qtype = 'tf' and n <> 2 then
      raise exception 'سؤال درست/نادرست باید دقیقاً دو گزینه داشته باشد';
    end if;
    if jsonb_typeof(q->'correct') <> 'number'
       or (q->>'correct') !~ '^[0-9]+$'
       or (q->>'correct')::int >= n then
      raise exception 'پاسخ درست یکی از سؤال‌ها نامعتبر است';
    end if;
  end loop;
end $$;

-- نسخه‌های قدیمیِ بدون توکن حذف می‌شوند (ساخت آزمون، دیدن آزمون و ثبت پاسخ فقط با نشست معتبر)
drop function if exists public.create_quiz(text,text,jsonb,text);
drop function if exists public.create_quiz(text,text,jsonb,text,text);
drop function if exists public.get_quiz(text,text);
drop function if exists public.submit_quiz(text,text,jsonb,text);
drop function if exists public.get_quiz(text);
drop function if exists public.submit_quiz(text,text,jsonb);

-- ساخت آزمون
create or replace function public.create_quiz(
  p_title text, p_description text, p_questions jsonb, p_secret text, p_token text, p_group text default null
) returns text
language plpgsql security definer set search_path = public as $$
declare
  new_id text;
  uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  if p_group is not null and not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then
    raise exception 'گروه پیدا نشد یا شما مدیر آن نیستید.';
  end if;
  if p_title is null or char_length(trim(p_title)) = 0 or char_length(p_title) > 200 then
    raise exception 'عنوان نامعتبر است';
  end if;
  if p_description is not null and char_length(p_description) > 2000 then
    raise exception 'توضیح خیلی بلند است';
  end if;
  if p_secret is null or char_length(p_secret) < 16 then
    raise exception 'کلید مدیریت نامعتبر است';
  end if;
  perform public.validate_questions(p_questions);

  new_id := substr(replace(gen_random_uuid()::text, '-', ''), 1, 8);
  insert into quizzes(id, title, description, questions, admin_hash, group_id)
  values (new_id, trim(p_title), coalesce(p_description, ''), p_questions,
          encode(sha256(convert_to(p_secret, 'utf8')), 'hex'), p_group);
  -- آزمون گروهی همان لحظه روی حساب مدیر گروه ثبت می‌شود تا لینک مدیریتش گم نشود
  if p_group is not null then
    insert into user_quizzes(user_id, quiz_id, secret) values (uid, new_id, p_secret)
    on conflict (user_id, quiz_id) do update set secret = excluded.secret;
  end if;
  return new_id;
end $$;

-- ویرایش آزمون (با کلید مدیریت). اگر آزمون نتیجه دارد، فقط با تأیید صریح انجام می‌شود و همه‌ی نتایج قبلی پاک می‌شوند.
create or replace function public.update_quiz(
  p_id text, p_secret text, p_title text, p_description text, p_questions jsonb,
  p_confirm_clear boolean default false
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  qz quizzes%rowtype;
  n int;
begin
  select * into qz from quizzes where id = p_id;
  if qz.id is null or qz.admin_hash <> encode(sha256(convert_to(coalesce(p_secret,''), 'utf8')), 'hex') then
    raise exception 'دسترسی نامعتبر';
  end if;
  if p_title is null or char_length(trim(p_title)) = 0 or char_length(p_title) > 200 then
    raise exception 'عنوان نامعتبر است';
  end if;
  if p_description is not null and char_length(p_description) > 2000 then
    raise exception 'توضیح خیلی بلند است';
  end if;
  perform public.validate_questions(p_questions);

  select count(*) into n from submissions where quiz_id = p_id;
  if n > 0 and not coalesce(p_confirm_clear, false) then
    raise exception 'این آزمون نتیجه دارد؛ برای ویرایش باید پاک شدن نتایج را تأیید کنید';
  end if;

  delete from submissions where quiz_id = p_id;
  update quizzes
     set title = trim(p_title), description = coalesce(p_description, ''), questions = p_questions
   where id = p_id;
  return jsonb_build_object('cleared', n);
end $$;

-- گرفتن آزمون برای شرکت‌کننده (بدون پاسخ صحیح)
create or replace function public.get_quiz(p_id text, p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if public.session_uid(p_token) is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  if not public.quiz_access_ok(p_id, public.session_uid(p_token)) then
    raise exception 'این آزمون مخصوص اعضای یک گروه است. اگر دعوت شده‌اید، از بخش «گروه‌ها» دعوت را بپذیرید.';
  end if;
  return (select jsonb_build_object(
    'id', id, 'title', title, 'description', description,
    'group_name', (select g.name from quiz_groups g where g.id = quizzes.group_id),
    'questions', coalesce((
      select jsonb_agg(
        jsonb_build_object('type', coalesce(t.e->>'type', 'mcq'), 'text', t.e->'text', 'options', t.e->'options')
        order by t.ord
      )
      from jsonb_array_elements(questions) with ordinality as t(e, ord)
    ), '[]'::jsonb)
  ) from quizzes where id = p_id);
end $$;

-- ثبت پاسخ‌ها و محاسبه‌ی نمره در سرور
create or replace function public.submit_quiz(p_id text, p_name text, p_answers jsonb, p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  qs jsonb;
  n int;
  i int;
  s int := 0;
  correct jsonb := '[]'::jsonb;
begin
  if public.session_uid(p_token) is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  select questions into qs from quizzes where id = p_id;
  if qs is null then raise exception 'آزمون پیدا نشد'; end if;
  if not public.quiz_access_ok(p_id, public.session_uid(p_token)) then
    raise exception 'این آزمون مخصوص اعضای یک گروه است.';
  end if;
  if p_name is null or char_length(trim(p_name)) = 0 then raise exception 'نام لازم است'; end if;
  if p_answers is null or jsonb_typeof(p_answers) <> 'array' then raise exception 'پاسخ‌ها نامعتبر است'; end if;
  n := jsonb_array_length(qs);
  for i in 0..n-1 loop
    correct := correct || to_jsonb((qs->i->>'correct')::int);
    if jsonb_typeof(p_answers->i) = 'number' and (p_answers->>i) ~ '^[0-9]+$'
       and (p_answers->>i)::int = (qs->i->>'correct')::int then
      s := s + 1;
    end if;
  end loop;
  insert into submissions(quiz_id, name, answers, score, total)
  values (p_id, left(trim(p_name), 100), p_answers, s, n);
  return jsonb_build_object('score', s, 'total', n, 'correct', correct);
end $$;

-- نتایج برای سازنده (با کلید مدیریت)
create or replace function public.get_results(p_id text, p_secret text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  q quizzes%rowtype;
begin
  select * into q from quizzes where id = p_id;
  if q.id is null or q.admin_hash <> encode(sha256(convert_to(coalesce(p_secret,''), 'utf8')), 'hex') then
    raise exception 'دسترسی نامعتبر';
  end if;
  return jsonb_build_object(
    'title', q.title,
    'description', q.description,
    'group_name', (select g.name from quiz_groups g where g.id = q.group_id),
    'group_id', q.group_id,
    'questions', q.questions,
    'submissions', coalesce((
      select jsonb_agg(jsonb_build_object(
        'name', name, 'score', score, 'total', total, 'answers', answers, 'created_at', created_at
      ) order by created_at desc) from submissions where quiz_id = p_id
    ), '[]'::jsonb)
  );
end $$;

revoke all on function public.create_quiz(text,text,jsonb,text,text,text) from public;
revoke all on function public.get_quiz(text,text) from public;
revoke all on function public.submit_quiz(text,text,jsonb,text) from public;
revoke all on function public.get_results(text,text) from public;
revoke all on function public.update_quiz(text,text,text,text,jsonb,boolean) from public;
revoke all on function public.validate_questions(jsonb) from public;
grant execute on function public.create_quiz(text,text,jsonb,text,text,text) to anon, authenticated;
grant execute on function public.get_quiz(text,text) to anon, authenticated;
grant execute on function public.submit_quiz(text,text,jsonb,text) to anon, authenticated;
grant execute on function public.get_results(text,text) to anon, authenticated;
grant execute on function public.update_quiz(text,text,text,text,jsonb,boolean) to anon, authenticated;

-- ============================================================
-- ثبت‌نام و ورود با شماره‌ی موبایل (کد یک‌بارمصرف)
-- این جدول‌ها و تابع‌ها فقط با کلید service_role (از داخل Edge Function auth-otp) قابل استفاده‌اند.
-- ============================================================
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique check (phone ~ '^09[0-9]{9}$'),
  created_at timestamptz not null default now()
);
-- نام و نام خانوادگی (برای حساب‌های قدیمی خالی می‌ماند تا در ورود بعدی پر شود)
alter table public.users add column if not exists name text;

-- ورود با ایمیل: حساب یا شماره‌ی موبایل دارد یا ایمیل
alter table public.users alter column phone drop not null;
alter table public.users add column if not exists email text;
alter table public.users add column if not exists avatar text check (avatar is null or avatar ~ '^g[1-8]$');
create unique index if not exists users_email_key on public.users(email) where email is not null;
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'users_ident_chk') then
    alter table public.users add constraint users_ident_chk check (phone is not null or email is not null);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'users_email_chk') then
    alter table public.users add constraint users_email_chk
      check (email is null or (email = lower(email) and char_length(email) <= 254 and email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'));
  end if;
end $$;

create table if not exists public.auth_otps (
  phone text primary key check (phone ~ '^09[0-9]{9}$'),
  code_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0,
  sent_at timestamptz not null default now(),
  window_start timestamptz not null default now(),
  window_count int not null default 1
);

create table if not exists public.user_sessions (
  token_hash text primary key,
  user_id uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists user_sessions_user_idx on public.user_sessions(user_id);

alter table public.users enable row level security;
alter table public.auth_otps enable row level security;
alter table public.user_sessions enable row level security;

-- ثبت کد جدید برای یک شماره (با محدودیت ارسال)
create or replace function public.otp_issue(p_phone text, p_hash text, p_ttl int default 120)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r auth_otps%rowtype;
  wait_s int;
  cnt int := 1;
  wstart timestamptz := now();
begin
  if p_phone is null or p_phone !~ '^09[0-9]{9}$' then
    return jsonb_build_object('ok', false, 'error', 'bad_phone');
  end if;
  if p_hash is null or char_length(p_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;

  select * into r from auth_otps where phone = p_phone for update;
  if found then
    wait_s := ceil(extract(epoch from (r.sent_at + interval '60 seconds' - now())))::int;
    if wait_s > 0 then
      return jsonb_build_object('ok', false, 'error', 'too_soon', 'retry_in', wait_s);
    end if;
    if r.window_start > now() - interval '1 hour' then
      if r.window_count >= 5 then
        return jsonb_build_object('ok', false, 'error', 'limit',
          'retry_in', ceil(extract(epoch from (r.window_start + interval '1 hour' - now())))::int);
      end if;
      cnt := r.window_count + 1;
      wstart := r.window_start;
    end if;
  end if;

  insert into auth_otps(phone, code_hash, expires_at, attempts, sent_at, window_start, window_count)
  values (p_phone, p_hash, now() + make_interval(secs => greatest(30, least(p_ttl, 600))), 0, now(), wstart, cnt)
  on conflict (phone) do update set
    code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0,
    sent_at = excluded.sent_at, window_start = excluded.window_start, window_count = excluded.window_count;

  return jsonb_build_object('ok', true, 'expires_in', greatest(30, least(p_ttl, 600)), 'resend_in', 60);
end $$;

-- بررسی کد؛ در صورت درست بودن کاربر ساخته (یا پیدا) می‌شود، نامش ذخیره می‌شود و نشست باز می‌شود
drop function if exists public.otp_verify(text, text, text);
create or replace function public.otp_verify(p_phone text, p_hash text, p_token_hash text, p_name text default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r auth_otps%rowtype;
  uid uuid;
  created boolean := false;
  nm text := nullif(btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g')), '');
  cur_name text;
begin
  if p_phone is null or p_phone !~ '^09[0-9]{9}$' or p_hash is null or p_token_hash is null or char_length(p_token_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  if nm is not null and char_length(nm) not between 2 and 60 then
    return jsonb_build_object('ok', false, 'error', 'bad_name');
  end if;

  select * into r from auth_otps where phone = p_phone for update;
  if not found or r.expires_at < now() then
    return jsonb_build_object('ok', false, 'error', 'expired');
  end if;
  if r.attempts >= 5 then
    return jsonb_build_object('ok', false, 'error', 'locked');
  end if;

  if r.code_hash <> p_hash then
    update auth_otps set attempts = attempts + 1 where phone = p_phone;
    return jsonb_build_object('ok', false, 'error', 'wrong', 'attempts_left', greatest(0, 4 - r.attempts));
  end if;

  delete from auth_otps where phone = p_phone;
  select id, name into uid, cur_name from users where phone = p_phone;
  if uid is null then
    insert into users(phone, name) values (p_phone, nm) returning id into uid;
    cur_name := nm;
    created := true;
  elsif nm is not null and nm is distinct from cur_name then
    update users set name = nm where id = uid;
    cur_name := nm;
  end if;
  delete from user_sessions where user_id = uid and expires_at < now();
  insert into user_sessions(token_hash, user_id, expires_at) values (p_token_hash, uid, now() + interval '30 days');
  return jsonb_build_object('ok', true, 'phone', p_phone, 'name', cur_name, 'created', created);
end $$;

create or replace function public.session_phone(p_token_hash text)
returns text
language sql security definer set search_path = public stable as $$
  select u.phone from user_sessions s join users u on u.id = s.user_id
  where s.token_hash = p_token_hash and s.expires_at > now();
$$;

create or replace function public.session_info(p_token_hash text)
returns jsonb
language sql security definer set search_path = public stable as $$
  select jsonb_build_object('phone', u.phone, 'email', u.email, 'name', u.name, 'avatar', u.avatar) from user_sessions s join users u on u.id = s.user_id
  where s.token_hash = p_token_hash and s.expires_at > now();
$$;

create or replace function public.session_end(p_token_hash text)
returns void
language sql security definer set search_path = public as $$
  delete from user_sessions where token_hash = p_token_hash;
$$;

revoke all on function public.otp_issue(text,text,int) from public, anon, authenticated;
revoke all on function public.otp_verify(text,text,text,text) from public, anon, authenticated;
revoke all on function public.session_info(text) from public, anon, authenticated;
revoke all on function public.session_phone(text) from public, anon, authenticated;
revoke all on function public.session_end(text) from public, anon, authenticated;
grant execute on function public.otp_issue(text,text,int) to service_role;
grant execute on function public.otp_verify(text,text,text,text) to service_role;
grant execute on function public.session_info(text) to service_role;
grant execute on function public.session_phone(text) to service_role;
grant execute on function public.session_end(text) to service_role;

-- ============================================================
-- ورود و ثبت‌نام با ایمیل (بدون رمز عبور): هر بار یک کد ۵ رقمی به ایمیل فرستاده می‌شود
-- حساب هر کاربر یا شماره‌ی موبایل دارد یا ایمیل.
-- ============================================================

-- پاک‌سازی نسخه‌ی قدیمیِ «ایمیل + رمز عبور»
drop function if exists public.email_code_issue(text, text, text, text, text, int, boolean);
drop function if exists public.email_code_verify(text, text, text, text, text);
drop function if exists public.email_code_verify(text, text, text, text);
drop function if exists public.email_code_check(text, text, text);
drop function if exists public.email_login_get(text);
drop function if exists public.email_login_ok(text, text);
drop function if exists public.email_login_fail(text);
drop table if exists public.auth_email_codes;
alter table public.users drop column if exists pass_hash;
alter table public.users drop column if exists login_fails;
alter table public.users drop column if exists locked_until;

create table if not exists public.email_otps (
  email        text primary key check (email = lower(email)),
  code_hash    text not null,
  expires_at   timestamptz not null,
  attempts     int not null default 0,
  sent_at      timestamptz not null default now(),
  window_start timestamptz not null default now(),
  window_count int not null default 1
);
alter table public.email_otps enable row level security;

-- ثبت کد جدید برای یک ایمیل (حداقل ۶۰ ثانیه فاصله و حداکثر ۵ کد در ساعت)
create or replace function public.email_otp_issue(p_email text, p_hash text, p_ttl int default 120)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r email_otps%rowtype;
  wait_s int;
  cnt int := 1;
  wstart timestamptz := now();
  ttl int := greatest(30, least(coalesce(p_ttl, 120), 600));
begin
  if p_email is null or p_email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' or char_length(p_email) > 254 or p_email <> lower(p_email) then
    return jsonb_build_object('ok', false, 'error', 'bad_email');
  end if;
  if p_hash is null or char_length(p_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  select * into r from email_otps where email = p_email for update;
  if found then
    wait_s := ceil(extract(epoch from (r.sent_at + interval '60 seconds' - now())))::int;
    if wait_s > 0 then
      return jsonb_build_object('ok', false, 'error', 'too_soon', 'retry_in', wait_s);
    end if;
    if r.window_start > now() - interval '1 hour' then
      if r.window_count >= 5 then
        return jsonb_build_object('ok', false, 'error', 'limit',
          'retry_in', ceil(extract(epoch from (r.window_start + interval '1 hour' - now())))::int);
      end if;
      cnt := r.window_count + 1;
      wstart := r.window_start;
    end if;
  end if;
  insert into email_otps(email, code_hash, expires_at, attempts, sent_at, window_start, window_count)
  values (p_email, p_hash, now() + make_interval(secs => ttl), 0, now(), wstart, cnt)
  on conflict (email) do update set
    code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0,
    sent_at = excluded.sent_at, window_start = excluded.window_start, window_count = excluded.window_count;
  return jsonb_build_object('ok', true, 'expires_in', ttl, 'resend_in', 60);
end $$;

-- تأیید کد: اگر حسابی با این ایمیل هست وارد می‌شود، وگرنه حساب تازه (با نام) ساخته می‌شود
create or replace function public.email_otp_verify(p_email text, p_hash text, p_token_hash text, p_name text default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r email_otps%rowtype;
  uid uuid;
  cur_name text;
  cur_avatar text;
  created boolean := false;
  nm text := nullif(btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g')), '');
begin
  if p_email is null or p_email <> lower(p_email) or p_hash is null or p_token_hash is null or char_length(p_token_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  if nm is not null and char_length(nm) not between 2 and 60 then
    return jsonb_build_object('ok', false, 'error', 'bad_name');
  end if;
  select id, name, avatar into uid, cur_name, cur_avatar from users where email = p_email;
  if uid is null and nm is null then
    return jsonb_build_object('ok', false, 'error', 'bad_name');
  end if;

  select * into r from email_otps where email = p_email for update;
  if not found or r.expires_at < now() then
    return jsonb_build_object('ok', false, 'error', 'expired');
  end if;
  if r.attempts >= 5 then
    return jsonb_build_object('ok', false, 'error', 'locked');
  end if;
  if r.code_hash <> p_hash then
    update email_otps set attempts = attempts + 1 where email = p_email;
    return jsonb_build_object('ok', false, 'error', 'wrong', 'attempts_left', greatest(0, 4 - r.attempts));
  end if;

  delete from email_otps where email = p_email;
  if uid is null then
    insert into users(email, name) values (p_email, nm) returning id into uid;
    cur_name := nm;
    created := true;
  elsif cur_name is null and nm is not null then
    update users set name = nm where id = uid;
    cur_name := nm;
  end if;
  delete from user_sessions where user_id = uid and expires_at < now();
  insert into user_sessions(token_hash, user_id, expires_at) values (p_token_hash, uid, now() + interval '30 days');
  return jsonb_build_object('ok', true, 'email', p_email, 'name', cur_name, 'avatar', cur_avatar, 'created', created);
end $$;

-- تغییر پروفایل (نام و رنگ آواتار) برای کاربرِ وارد‌شده
create or replace function public.profile_update(p_token_hash text, p_name text, p_avatar text default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid;
  nm text := nullif(btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g')), '');
  av text := nullif(btrim(coalesce(p_avatar, '')), '');
begin
  if nm is null or char_length(nm) not between 2 and 60 then
    return jsonb_build_object('ok', false, 'error', 'bad_name');
  end if;
  if av is not null and av !~ '^g[1-8]$' then
    return jsonb_build_object('ok', false, 'error', 'bad_avatar');
  end if;
  select s.user_id into uid from user_sessions s where s.token_hash = p_token_hash and s.expires_at > now();
  if uid is null then
    return jsonb_build_object('ok', false, 'error', 'no_session');
  end if;
  update users set name = nm, avatar = av where id = uid;
  return jsonb_build_object('ok', true, 'name', nm, 'avatar', av);
end $$;

revoke all on function public.email_otp_issue(text, text, int) from public, anon, authenticated;
revoke all on function public.email_otp_verify(text, text, text, text) from public, anon, authenticated;
revoke all on function public.profile_update(text, text, text) from public, anon, authenticated;
grant execute on function public.email_otp_issue(text, text, int) to service_role;
grant execute on function public.email_otp_verify(text, text, text, text) to service_role;
grant execute on function public.profile_update(text, text, text) to service_role;


-- ============================================================
-- آزمون‌های هر حساب (روی شماره‌ی کاربر ذخیره می‌شوند، نه روی دستگاه)
-- کاربر با نشست خودش (token) شناخته می‌شود؛ فقط هش آن در جدول user_sessions است.
-- ============================================================
create table if not exists public.user_quizzes (
  user_id    uuid not null references public.users(id) on delete cascade,
  quiz_id    text not null references public.quizzes(id) on delete cascade,
  secret     text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, quiz_id)
);
alter table public.user_quizzes enable row level security;

-- شناسه‌ی کاربر از روی نشست (داخلی؛ از بیرون قابل‌فراخوانی نیست)
create or replace function public.session_uid(p_token text)
returns uuid
language sql security definer set search_path = public stable as $$
  select s.user_id from user_sessions s
  where p_token ~ '^[0-9a-f]{64}$'
    and s.token_hash = encode(sha256(convert_to(p_token, 'utf8')), 'hex')
    and s.expires_at > now();
$$;
revoke all on function public.session_uid(text) from public, anon, authenticated;

-- افزودن یک آزمون به حساب (فقط اگر کلید مدیریت درست باشد)
create or replace function public.account_claim(p_token text, p_id text, p_secret text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then return jsonb_build_object('ok', false, 'error', 'no_session'); end if;
  if p_id is null or p_secret is null or char_length(p_secret) < 16 or char_length(p_secret) > 128 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  if not exists (select 1 from quizzes where id = p_id) then
    return jsonb_build_object('ok', false, 'error', 'not_found');
  end if;
  if not exists (select 1 from quizzes where id = p_id and admin_hash = encode(sha256(convert_to(p_secret, 'utf8')), 'hex')) then
    return jsonb_build_object('ok', false, 'error', 'bad_secret');
  end if;
  insert into user_quizzes(user_id, quiz_id, secret) values (uid, p_id, p_secret)
  on conflict (user_id, quiz_id) do update set secret = excluded.secret;
  return jsonb_build_object('ok', true);
end $$;

-- فهرست آزمون‌های حساب
create or replace function public.account_quizzes(p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; items jsonb;
begin
  uid := public.session_uid(p_token);
  if uid is null then return jsonb_build_object('ok', false, 'error', 'no_session'); end if;
  select coalesce(jsonb_agg(x.j order by x.created_at desc), '[]'::jsonb) into items
  from (
    select uq.created_at,
           jsonb_build_object('id', q.id, 'secret', uq.secret, 'title', q.title, 'created_at', q.created_at,
                              'participants', (select count(*) from submissions s where s.quiz_id = q.id)) as j
    from user_quizzes uq join quizzes q on q.id = uq.quiz_id
    where uq.user_id = uid
    order by uq.created_at desc
    limit 200
  ) x;
  return jsonb_build_object('ok', true, 'items', items);
end $$;

revoke all on function public.account_claim(text,text,text) from public;
revoke all on function public.account_quizzes(text) from public;
grant execute on function public.account_claim(text,text,text) to anon, authenticated;
grant execute on function public.account_quizzes(text) to anon, authenticated;


-- ============================================================
-- گروه‌ها: آزمون عمومی (همه با لینک) یا آزمون گروهی (فقط اعضای گروه)
-- مدیر گروه شماره‌ها را دعوت می‌کند؛ هر کس خودش دعوت را می‌پذیرد یا رد می‌کند.
-- ============================================================
create table if not exists public.quiz_groups (
  id         text primary key,
  owner_id   uuid not null references public.users(id) on delete cascade,
  name       text not null check (char_length(name) between 2 and 60),
  created_at timestamptz not null default now()
);
create index if not exists quiz_groups_owner_idx on public.quiz_groups(owner_id);

create table if not exists public.group_members (
  group_id  text not null references public.quiz_groups(id) on delete cascade,
  user_id   uuid not null references public.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create index if not exists group_members_user_idx on public.group_members(user_id);

create table if not exists public.group_invites (
  group_id   text not null references public.quiz_groups(id) on delete cascade,
  phone      text not null,          -- شماره‌ی موبایل یا ایمیل دعوت‌شده (نام ستون از قدیم مانده)
  invited_by uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (group_id, phone)
);
create index if not exists group_invites_phone_idx on public.group_invites(phone);
alter table public.group_invites drop constraint if exists group_invites_phone_check;
alter table public.group_invites drop constraint if exists group_invites_ident_chk;
alter table public.group_invites add constraint group_invites_ident_chk
  check (phone ~ '^09[0-9]{9}$' or (phone = lower(phone) and phone ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'));

alter table public.quiz_groups   enable row level security;
alter table public.group_members enable row level security;
alter table public.group_invites enable row level security;

alter table public.quizzes add column if not exists group_id text references public.quiz_groups(id) on delete cascade;
create index if not exists quizzes_group_idx on public.quizzes(group_id);

-- آیا این کاربر مدیر یا عضو گروه است؟ (داخلی)
create or replace function public.is_group_member(p_uid uuid, p_group text)
returns boolean
language sql security definer set search_path = public stable as $$
  select p_uid is not null and (
    exists (select 1 from quiz_groups g where g.id = p_group and g.owner_id = p_uid)
    or exists (select 1 from group_members m where m.group_id = p_group and m.user_id = p_uid)
  );
$$;

-- آیا این کاربر می‌تواند آزمون را ببیند؟ آزمون عمومی برای هر کاربر واردشده؛ آزمون گروهی فقط برای اعضا (داخلی)
create or replace function public.quiz_access_ok(p_quiz text, p_uid uuid)
returns boolean
language plpgsql security definer set search_path = public stable as $$
declare gid text; found_q boolean;
begin
  select group_id, true into gid, found_q from quizzes where id = p_quiz;
  if found_q is null then return true; end if;      -- آزمونی نیست؛ خطای «پیدا نشد» جای دیگر داده می‌شود
  if p_uid is null then return false; end if;
  if gid is null then return true; end if;
  return public.is_group_member(p_uid, gid);
end $$;

create or replace function public.group_create(p_token text, p_name text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; nm text; gid text;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  nm := btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g'));
  if char_length(nm) < 2 or char_length(nm) > 60 then raise exception 'نام گروه باید بین ۲ تا ۶۰ حرف باشد.'; end if;
  if (select count(*) from quiz_groups where owner_id = uid) >= 20 then raise exception 'حداکثر ۲۰ گروه می‌توانید بسازید.'; end if;
  gid := substr(replace(gen_random_uuid()::text, '-', ''), 1, 8);
  insert into quiz_groups(id, owner_id, name) values (gid, uid, nm);
  return jsonb_build_object('id', gid, 'name', nm);
end $$;

-- گروه‌های من + دعوت‌های در انتظار من (یک فراخوانی سبک برای صفحه و نشان اعلان)
create or replace function public.groups_mine(p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; ph text; gs jsonb; inv jsonb;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  select coalesce(phone, email) into ph from users where id = uid;
  select coalesce(jsonb_agg(x.j order by x.ord desc, x.nm), '[]'::jsonb) into gs from (
    select g.name as nm, g.created_at as ord,
      jsonb_build_object(
        'id', g.id, 'name', g.name,
        'role', case when g.owner_id = uid then 'owner' else 'member' end,
        'members', 1 + (select count(*) from group_members m where m.group_id = g.id),
        'quizzes', (select count(*) from quizzes q where q.group_id = g.id),
        'owner_name', coalesce((select u.name from users u where u.id = g.owner_id), 'مدیر گروه')
      ) as j
    from quiz_groups g
    where g.owner_id = uid or exists (select 1 from group_members m where m.group_id = g.id and m.user_id = uid)
  ) x;
  select coalesce(jsonb_agg(jsonb_build_object(
      'group_id', g.id, 'group_name', g.name,
      'from_name', coalesce((select u.name from users u where u.id = i.invited_by), 'مدیر گروه'),
      'created_at', i.created_at) order by i.created_at desc), '[]'::jsonb) into inv
  from group_invites i join quiz_groups g on g.id = i.group_id
  where i.phone = ph;
  return jsonb_build_object('groups', gs, 'invites', inv);
end $$;

-- جزئیات یک گروه (فقط مدیر و اعضا). شماره‌ها و کلید مدیریت فقط برای مدیر برگردانده می‌شود.
create or replace function public.group_get(p_token text, p_group text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; g quiz_groups%rowtype; is_owner boolean; mem jsonb; inv jsonb; qz jsonb;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  select * into g from quiz_groups where id = p_group;
  if g.id is null or not public.is_group_member(uid, p_group) then raise exception 'این گروه پیدا نشد.'; end if;
  is_owner := g.owner_id = uid;

  select coalesce(jsonb_agg(x.j order by x.ord, x.nm), '[]'::jsonb) into mem from (
    select 0 as ord, coalesce(u.name, 'مدیر گروه') as nm,
      jsonb_build_object('name', coalesce(u.name, 'مدیر گروه'), 'role', 'owner',
                         'phone', case when is_owner then coalesce(u.phone, u.email) else null end) as j
    from users u where u.id = g.owner_id
    union all
    select 1, coalesce(u.name, 'کاربر'),
      jsonb_build_object('name', coalesce(u.name, 'کاربر'), 'role', 'member',
                         'user_id', case when is_owner then u.id::text else null end,
                         'phone', case when is_owner then coalesce(u.phone, u.email) else null end)
    from group_members m join users u on u.id = m.user_id where m.group_id = p_group
  ) x;

  if is_owner then
    select coalesce(jsonb_agg(jsonb_build_object('phone', i.phone, 'created_at', i.created_at) order by i.created_at desc), '[]'::jsonb)
      into inv from group_invites i where i.group_id = p_group;
  else
    inv := '[]'::jsonb;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'id', q.id, 'title', q.title, 'created_at', q.created_at,
      'participants', case when is_owner then (select count(*) from submissions s where s.quiz_id = q.id) else null end,
      'secret', case when is_owner then (select uq.secret from user_quizzes uq where uq.quiz_id = q.id and uq.user_id = uid) else null end
    ) order by q.created_at desc), '[]'::jsonb)
    into qz from quizzes q where q.group_id = p_group;

  return jsonb_build_object('id', g.id, 'name', g.name, 'role', case when is_owner then 'owner' else 'member' end,
                            'members', mem, 'invites', inv, 'quizzes', qz);
end $$;

-- دعوت یک شماره (فقط مدیر). کسی که دعوت می‌شود فوراً عضو نمی‌شود.
create or replace function public.group_invite(p_token text, p_group text, p_phone text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; own_phone text; target uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند دعوت بفرستد.'; end if;
  p_phone := lower(btrim(coalesce(p_phone, '')));
  if p_phone !~ '^09[0-9]{9}$' and (p_phone !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' or char_length(p_phone) > 254) then
    raise exception 'شماره‌ی موبایل یا ایمیل معتبر نیست. مثل ۰۹۱۲۳۴۵۶۷۸۹ یا name@example.com وارد کنید.';
  end if;
  select coalesce(phone, email) into own_phone from users where id = uid;
  if own_phone = p_phone then raise exception 'شما مدیر این گروه هستید و نیازی به دعوت ندارید.'; end if;
  select id into target from users where phone = p_phone or email = p_phone;
  if target is not null and exists (select 1 from group_members where group_id = p_group and user_id = target) then
    raise exception 'این شخص قبلاً عضو گروه است.';
  end if;
  if exists (select 1 from group_invites where group_id = p_group and phone = p_phone) then
    raise exception 'برای این شماره یا ایمیل قبلاً دعوت فرستاده شده و منتظر پاسخ است.';
  end if;
  if (select count(*) from group_invites where group_id = p_group) >= 50 then raise exception 'حداکثر ۵۰ دعوت در انتظار می‌تواند باشد. چند دعوت را لغو کنید یا منتظر پاسخ بمانید.'; end if;
  if (select count(*) from group_members where group_id = p_group) >= 200 then raise exception 'گروه به حداکثر ظرفیت (۲۰۰ عضو) رسیده است.'; end if;
  if (select count(*) from group_invites where invited_by = uid and created_at > now() - interval '1 hour') >= 40 then
    raise exception 'در یک ساعت گذشته دعوت‌های زیادی فرستاده‌اید. کمی بعد دوباره تلاش کنید.';
  end if;
  insert into group_invites(group_id, phone, invited_by) values (p_group, p_phone, uid);
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.group_invite_cancel(p_token text, p_group text, p_phone text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند دعوت را لغو کند.'; end if;
  delete from group_invites where group_id = p_group and phone = p_phone;
  return jsonb_build_object('ok', true);
end $$;

-- پذیرفتن یا رد دعوت (فقط صاحب همان شماره)
create or replace function public.group_invite_respond(p_token text, p_group text, p_accept boolean)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; ph text;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  select coalesce(phone, email) into ph from users where id = uid;
  if not exists (select 1 from group_invites where group_id = p_group and phone = ph) then
    raise exception 'این دعوت دیگر معتبر نیست.';
  end if;
  if coalesce(p_accept, false) then
    if (select count(*) from group_members where group_id = p_group) >= 200 then raise exception 'گروه به حداکثر ظرفیت رسیده است.'; end if;
    insert into group_members(group_id, user_id) values (p_group, uid) on conflict do nothing;
  end if;
  delete from group_invites where group_id = p_group and phone = ph;
  return jsonb_build_object('ok', true, 'joined', coalesce(p_accept, false));
end $$;

-- حذف یک عضو (فقط مدیر)
create or replace function public.group_member_remove(p_token text, p_group text, p_user text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; target uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند عضو را حذف کند.'; end if;
  if p_user is null or p_user !~ '^[0-9a-f-]{36}$' then raise exception 'عضو نامعتبر است.'; end if;
  target := p_user::uuid;
  delete from group_members where group_id = p_group and user_id = target;
  return jsonb_build_object('ok', true);
end $$;

-- ترک گروه (عضو عادی)
create or replace function public.group_leave(p_token text, p_group text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then
    raise exception 'مدیر گروه نمی‌تواند آن را ترک کند. اگر لازم نیست، گروه را حذف کنید.';
  end if;
  delete from group_members where group_id = p_group and user_id = uid;
  return jsonb_build_object('ok', true);
end $$;

-- حذف گروه (فقط مدیر): آزمون‌های گروه و نتایجشان هم پاک می‌شود
create or replace function public.group_delete(p_token text, p_group text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند آن را حذف کند.'; end if;
  delete from quiz_groups where id = p_group;
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.is_group_member(uuid,text) from public, anon, authenticated;
revoke all on function public.quiz_access_ok(text,uuid) from public, anon, authenticated;
revoke all on function public.group_create(text,text) from public;
revoke all on function public.groups_mine(text) from public;
revoke all on function public.group_get(text,text) from public;
revoke all on function public.group_invite(text,text,text) from public;
revoke all on function public.group_invite_cancel(text,text,text) from public;
revoke all on function public.group_invite_respond(text,text,boolean) from public;
revoke all on function public.group_member_remove(text,text,text) from public;
revoke all on function public.group_leave(text,text) from public;
revoke all on function public.group_delete(text,text) from public;
grant execute on function public.group_create(text,text) to anon, authenticated;
grant execute on function public.groups_mine(text) to anon, authenticated;
grant execute on function public.group_get(text,text) to anon, authenticated;
grant execute on function public.group_invite(text,text,text) to anon, authenticated;
grant execute on function public.group_invite_cancel(text,text,text) to anon, authenticated;
grant execute on function public.group_invite_respond(text,text,boolean) to anon, authenticated;
grant execute on function public.group_member_remove(text,text,text) to anon, authenticated;
grant execute on function public.group_leave(text,text) to anon, authenticated;
grant execute on function public.group_delete(text,text) to anon, authenticated;

-- تغییر نام گروه (فقط مدیر)
create or replace function public.group_rename(p_token text, p_group text, p_name text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; nm text;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند نام را تغییر دهد.'; end if;
  nm := btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g'));
  if char_length(nm) < 2 or char_length(nm) > 60 then raise exception 'نام گروه باید بین ۲ تا ۶۰ حرف باشد.'; end if;
  update quiz_groups set name = nm where id = p_group;
  return jsonb_build_object('ok', true, 'name', nm);
end $$;

-- واگذاری مدیریت به یکی از اعضا (فقط مدیر فعلی). مدیر قبلی عضو عادی می‌شود،
-- و کلید مدیریت آزمون‌های گروه عوض و به مدیر جدید داده می‌شود (لینک‌های قدیمی مدیر قبلی از کار می‌افتد).
create or replace function public.group_transfer(p_token text, p_group text, p_user text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; target uuid; q record; new_secret text;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not exists (select 1 from quiz_groups where id = p_group and owner_id = uid) then raise exception 'فقط مدیر گروه می‌تواند مدیر را عوض کند.'; end if;
  if p_user is null or p_user !~ '^[0-9a-f-]{36}$' then raise exception 'عضو نامعتبر است.'; end if;
  target := p_user::uuid;
  if not exists (select 1 from group_members where group_id = p_group and user_id = target) then raise exception 'مدیر جدید باید یکی از اعضای گروه باشد.'; end if;
  if (select count(*) from quiz_groups where owner_id = target) >= 20 then raise exception 'این عضو به سقف ۲۰ گروه رسیده و نمی‌تواند مدیر گروه جدید شود.'; end if;

  update quiz_groups set owner_id = target where id = p_group;
  delete from group_members where group_id = p_group and user_id = target;
  insert into group_members(group_id, user_id) values (p_group, uid) on conflict do nothing;

  for q in select id from quizzes where group_id = p_group loop
    new_secret := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');
    update quizzes set admin_hash = encode(sha256(convert_to(new_secret, 'utf8')), 'hex') where id = q.id;
    delete from user_quizzes where quiz_id = q.id;
    insert into user_quizzes(user_id, quiz_id, secret) values (target, q.id, new_secret);
  end loop;
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.group_rename(text,text,text) from public;
revoke all on function public.group_transfer(text,text,text) from public;
grant execute on function public.group_rename(text,text,text) to anon, authenticated;
grant execute on function public.group_transfer(text,text,text) to anon, authenticated;


-- ============================================================
-- گپ گروه: پیام، پاسخ (ریپلای)، ویرایش و حذف پیام خود
-- فقط مدیر و اعضای گروه می‌توانند بخوانند و بنویسند.
-- rev: شماره‌ی تغییر؛ با هر پیام تازه، ویرایش یا حذف بالاتر می‌رود تا مرورگر فقط تغییرها را بگیرد.
-- ============================================================
create sequence if not exists public.group_msg_rev_seq;

create table if not exists public.group_messages (
  id         bigserial primary key,
  group_id   text not null references public.quiz_groups(id) on delete cascade,
  user_id    uuid not null references public.users(id) on delete cascade,
  body       text not null default '' check (char_length(body) <= 2000),
  reply_to   bigint references public.group_messages(id) on delete set null,
  deleted    boolean not null default false,
  created_at timestamptz not null default now(),
  edited_at  timestamptz,
  rev        bigint not null default nextval('public.group_msg_rev_seq')
);
create index if not exists group_messages_group_id_idx  on public.group_messages(group_id, id desc);
create index if not exists group_messages_group_rev_idx on public.group_messages(group_id, rev);
create index if not exists group_messages_user_idx      on public.group_messages(user_id, created_at desc);
alter table public.group_messages enable row level security;

-- ساخت JSON یک پیام برای کاربر p_uid (داخلی)
create table if not exists public.group_msg_gone (
  id bigint primary key,
  group_id text not null references public.quiz_groups(id) on delete cascade,
  rev bigint not null default nextval('public.group_msg_rev_seq'),
  created_at timestamptz not null default now());
create index if not exists group_msg_gone_rev on public.group_msg_gone (group_id, rev);
create index if not exists group_msg_gone_age on public.group_msg_gone (created_at);
alter table public.group_msg_gone enable row level security;
-- پیام‌هایی که قبلاً با روش قدیمی «علامت حذف» خورده بودند کاملاً پاک شوند
delete from public.group_messages where deleted;

create or replace function public.chat_json(m public.group_messages, p_uid uuid)
returns jsonb
language sql security definer set search_path = public stable as $$
  select jsonb_build_object(
    'id', m.id,
    'rev', m.rev,
    'u', left(md5(m.user_id::text || m.group_id), 8),
    'name', coalesce(u.name, 'کاربر'),
    'owner', exists (select 1 from quiz_groups g where g.id = m.group_id and g.owner_id = m.user_id),
    'mine', m.user_id = p_uid,
    'body', case when m.deleted then '' else m.body end,
    'deleted', m.deleted,
    'edited', m.edited_at is not null and not m.deleted,
    'created_at', m.created_at,
    'reply', (
      select jsonb_build_object('id', r.id, 'name', coalesce(ru.name, 'کاربر'),
                                'body', case when r.deleted then '' else left(r.body, 140) end, 'deleted', r.deleted)
      from group_messages r left join users ru on ru.id = r.user_id
      where r.id = m.reply_to
    )
  ) from users u where u.id = m.user_id;
$$;

-- خواندن پیام‌ها. سه حالت:
--   p_since  (عدد rev): فقط پیام‌های تازه یا تغییرکرده بعد از آن
--   p_before (شناسه‌ی پیام): صفحه‌ی پیام‌های قدیمی‌تر
--   هیچ‌کدام: آخرین پیام‌ها (بار اول)
create or replace function public.chat_list(p_token text, p_group text, p_since bigint default null, p_before bigint default null, p_limit int default 40)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; lim int; msgs jsonb; more boolean := false; cur_rev bigint; n int; gone jsonb; grev bigint;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not public.is_group_member(uid, p_group) then raise exception 'این گروه پیدا نشد.'; end if;
  lim := greatest(1, least(coalesce(p_limit, 40), 100));

  if p_since is not null then
    select coalesce(jsonb_agg(public.chat_json(x, uid) order by x.rev), '[]'::jsonb), coalesce(max(x.rev), p_since), count(*)
      into msgs, cur_rev, n
      from (select * from group_messages where group_id = p_group and rev > p_since order by rev limit 200) x;
    select coalesce(jsonb_agg(g.id order by g.rev), '[]'::jsonb), max(g.rev)
      into gone, grev
      from group_msg_gone g where g.group_id = p_group and g.rev > p_since and (n < 200 or g.rev <= cur_rev);
    if n < 200 and grev is not null and grev > cur_rev then cur_rev := grev; end if;
    return jsonb_build_object('messages', msgs, 'gone', gone, 'rev', cur_rev);
  end if;

  select greatest(coalesce((select max(rev) from group_messages where group_id = p_group), 0),
                  coalesce((select max(rev) from group_msg_gone where group_id = p_group), 0)) into cur_rev;
  select count(*) > lim into more
    from (select 1 from group_messages where group_id = p_group and (p_before is null or id < p_before) limit lim + 1) c;
  select coalesce(jsonb_agg(public.chat_json(x, uid) order by x.id), '[]'::jsonb) into msgs
    from (select * from group_messages where group_id = p_group and (p_before is null or id < p_before) order by id desc limit lim) x;
  return jsonb_build_object('messages', msgs, 'more', more, 'rev', cur_rev);
end $$;

create or replace function public.chat_send(p_token text, p_group text, p_body text, p_reply bigint default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; b text; m public.group_messages;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  if not public.is_group_member(uid, p_group) then raise exception 'این گروه پیدا نشد.'; end if;
  b := btrim(coalesce(p_body, ''), E' \t\r\n');
  if char_length(b) < 1 then raise exception 'پیام خالی است.'; end if;
  if char_length(b) > 2000 then raise exception 'پیام خیلی بلند است (حداکثر ۲۰۰۰ حرف).'; end if;
  if p_reply is not null and not exists (select 1 from group_messages where id = p_reply and group_id = p_group) then
    raise exception 'پیامی که می‌خواهید به آن پاسخ دهید پیدا نشد.';
  end if;
  if (select count(*) from group_messages where user_id = uid and created_at > now() - interval '10 seconds') >= 10 then
    raise exception 'پیام‌ها خیلی سریع فرستاده می‌شوند؛ چند لحظه صبر کنید.';
  end if;
  perform pg_advisory_xact_lock(hashtext('chat:' || p_group));
  insert into group_messages(group_id, user_id, body, reply_to) values (p_group, uid, b, p_reply) returning * into m;
  return public.chat_json(m, uid);
end $$;

create or replace function public.chat_edit(p_token text, p_msg bigint, p_body text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; b text; m public.group_messages;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  select * into m from group_messages where id = p_msg;
  if m.id is null or m.user_id <> uid or m.deleted or not public.is_group_member(uid, m.group_id) then
    raise exception 'این پیام را نمی‌توانید ویرایش کنید.';
  end if;
  b := btrim(coalesce(p_body, ''), E' \t\r\n');
  if char_length(b) < 1 then raise exception 'پیام خالی است.'; end if;
  if char_length(b) > 2000 then raise exception 'پیام خیلی بلند است (حداکثر ۲۰۰۰ حرف).'; end if;
  if b <> m.body then
    perform pg_advisory_xact_lock(hashtext('chat:' || m.group_id));
    update group_messages set body = b, edited_at = now(), rev = nextval('public.group_msg_rev_seq') where id = p_msg returning * into m;
  end if;
  return public.chat_json(m, uid);
end $$;

create or replace function public.chat_delete(p_token text, p_msg bigint)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; m public.group_messages;
begin
  uid := public.session_uid(p_token);
  if uid is null then raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.'; end if;
  select * into m from group_messages where id = p_msg;
  if m.id is null or m.user_id <> uid or not public.is_group_member(uid, m.group_id) then
    raise exception 'این پیام را نمی‌توانید حذف کنید.';
  end if;
  perform pg_advisory_xact_lock(hashtext('chat:' || m.group_id));
  -- پیام کاملاً پاک می‌شود؛ فقط شناسه‌اش چند روز می‌ماند تا بقیه‌ی اعضا بفهمند باید آن را از صفحه بردارند
  insert into group_msg_gone(id, group_id) values (m.id, m.group_id) on conflict do nothing;
  delete from group_messages where id = m.id;
  delete from group_msg_gone where created_at < now() - interval '3 days';
  return jsonb_build_object('id', m.id, 'gone', true);
end $$;

revoke all on function public.chat_json(public.group_messages, uuid) from public, anon, authenticated;
revoke all on function public.chat_list(text,text,bigint,bigint,int) from public;
revoke all on function public.chat_send(text,text,text,bigint) from public;
revoke all on function public.chat_edit(text,bigint,text) from public;
revoke all on function public.chat_delete(text,bigint) from public;
grant execute on function public.chat_list(text,text,bigint,bigint,int) to anon, authenticated;
grant execute on function public.chat_send(text,text,text,bigint) to anon, authenticated;
grant execute on function public.chat_edit(text,bigint,text) to anon, authenticated;
grant execute on function public.chat_delete(text,bigint) to anon, authenticated;
