const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const fail = (error, message, status, extra = {}) => json({ ok: false, error, message, ...extra }, status);
const enc = new TextEncoder();
async function sha256Hex(s) {
  const buf = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
}
function normalizePhone(raw) {
  let s = String(raw ?? "").trim();
  s = s.replace(/[۰-۹]/g, (d) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(d)));
  s = s.replace(/[٠-٩]/g, (d) => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(d)));
  s = s.replace(/[\s\-()]/g, "");
  if (s.startsWith("+98")) s = "0" + s.slice(3);
  else if (s.startsWith("0098")) s = "0" + s.slice(4);
  else if (/^98\d{10}$/.test(s)) s = "0" + s.slice(2);
  else if (/^9\d{9}$/.test(s)) s = "0" + s;
  return /^09\d{9}$/.test(s) ? s : null;
}
function randomCode() {
  const a = new Uint32Array(1);
  const limit = Math.floor(4294967296 / 1e5) * 1e5;
  do
    crypto.getRandomValues(a);
  while (a[0] >= limit);
  return String(a[0] % 1e5).padStart(5, "0");
}
function randomToken() {
  const a = new Uint8Array(32);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("");
}
const SB_URL = (Deno.env.get("SUPABASE_URL") || "").replace(/\/$/, "");
const SB_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
async function rpc(name, args) {
  const res = await fetch(`${SB_URL}/rest/v1/rpc/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}` },
    body: JSON.stringify(args)
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
  }
  if (!res.ok) throw new Error(data && (data.message || data.hint) || `db ${res.status}`);
  return data;
}
const codeHash = (phone, code) => sha256Hex(`${Deno.env.get("OTP_PEPPER") || SB_KEY}|${phone}|${code}`);
async function sendSms(phone, code) {
  const provider = (Deno.env.get("SMS_PROVIDER") || "").toLowerCase();
  if (provider === "kavenegar") {
    const key = Deno.env.get("KAVENEGAR_API_KEY");
    const template = Deno.env.get("KAVENEGAR_TEMPLATE");
    if (!key || !template) throw new Error("kavenegar not configured");
    const url = `https://api.kavenegar.com/v1/${encodeURIComponent(key)}/verify/lookup.json?receptor=${phone}&token=${code}&template=${encodeURIComponent(template)}`;
    const res = await fetch(url);
    const body = await res.json().catch(() => null);
    if (!res.ok || !body || body.return?.status !== 200) {
      throw new Error(`kavenegar ${body?.return?.status ?? res.status}: ${body?.return?.message ?? ""}`);
    }
    return;
  }
  if (provider === "smsir") {
    const key = Deno.env.get("SMSIR_API_KEY");
    const templateId = Number(Deno.env.get("SMSIR_TEMPLATE_ID"));
    const paramName = Deno.env.get("SMSIR_PARAM_NAME") || "Code";
    if (!key || !Number.isInteger(templateId) || templateId <= 0) throw new Error("smsir not configured");
    const res = await fetch("https://api.sms.ir/v1/send/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json", "X-API-KEY": key },
      body: JSON.stringify({ mobile: phone, templateId, parameters: [{ name: paramName, value: code }] })
    });
    const body = await res.json().catch(() => null);
    if (!res.ok || !body || body.status !== 1) {
      throw new Error(`smsir http ${res.status} status ${body?.status ?? "?"}: ${body?.message ?? ""}`);
    }
    return;
  }
  throw new Error("no sms provider");
}
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
function normalizeEmail(raw) {
  const s = String(raw ?? "").trim().toLowerCase();
  return s.length <= 254 && EMAIL_RE.test(s) ? s : null;
}
const toLatin = (v) => v.replace(/[۰-۹]/g, (d) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(d)));
const emailConfigured = () => !!(Deno.env.get("RESEND_API_KEY") || "").trim();
async function sendEmail(to, code) {
  const key = (Deno.env.get("RESEND_API_KEY") || "").trim();
  if (!key) throw new Error("email not configured");
  const from = (Deno.env.get("EMAIL_FROM") || "\u067E\u0627\u0632\u0645\u0648\u0646\u06A9 <noreply@pazmoonak.com>").trim();
  const what = "\u0648\u0631\u0648\u062F";
  const html = `<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;max-width:480px;margin:0 auto;padding:24px;color:#0C2A20"><h2 style="margin:0 0 12px;color:#0F5132">\u067E\u0627\u0632\u0645\u0648\u0646\u06A9</h2><p style="margin:0 0 12px">\u06A9\u062F \u062A\u0623\u06CC\u06CC\u062F ${what} \u0634\u0645\u0627:</p><div style="font-size:34px;font-weight:700;letter-spacing:8px;direction:ltr;text-align:center;background:#F1F7F3;border-radius:14px;padding:16px;margin:0 0 14px">${code}</div><p style="margin:0 0 6px;color:#4A6659">\u0627\u06CC\u0646 \u06A9\u062F \u06F2 \u062F\u0642\u06CC\u0642\u0647 \u0627\u0639\u062A\u0628\u0627\u0631 \u062F\u0627\u0631\u062F.</p><p style="margin:0;color:#4A6659;font-size:13px">\u0627\u06AF\u0631 \u0634\u0645\u0627 \u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0631\u0627 \u0646\u062F\u0627\u062F\u0647\u200C\u0627\u06CC\u062F\u060C \u0627\u06CC\u0646 \u0627\u06CC\u0645\u06CC\u0644 \u0631\u0627 \u0646\u0627\u062F\u06CC\u062F\u0647 \u0628\u06AF\u06CC\u0631\u06CC\u062F \u0648 \u06A9\u062F\u06CC \u0631\u0627 \u0628\u0647 \u06A9\u0633\u06CC \u0646\u06AF\u0648\u06CC\u06CC\u062F.</p></div>`;
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [to], subject: `\u06A9\u062F \u062A\u0623\u06CC\u06CC\u062F \u067E\u0627\u0632\u0645\u0648\u0646\u06A9: ${code}`, html, text: `\u06A9\u062F \u062A\u0623\u06CC\u06CC\u062F ${what} \u067E\u0627\u0632\u0645\u0648\u0646\u06A9: ${code}
\u0627\u06CC\u0646 \u06A9\u062F \u06F2 \u062F\u0642\u06CC\u0642\u0647 \u0627\u0639\u062A\u0628\u0627\u0631 \u062F\u0627\u0631\u062F.` })
  });
  if (!res.ok) throw new Error(`resend ${res.status} ${(await res.text().catch(() => "")).slice(0, 200)}`);
}
const emailCodeHash = (email, code) => sha256Hex(`${Deno.env.get("OTP_PEPPER") || SB_KEY}|email|${email}|${code}`);
const devMode = () => Deno.env.get("OTP_DEV_MODE") === "1";
const smsConfigured = () => !!(Deno.env.get("SMS_PROVIDER") || "").trim();
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST") return fail("method", "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.", 405);
  if (!SB_URL || !SB_KEY) return fail("config", "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A \u0633\u0631\u0648\u0631 \u06A9\u0627\u0645\u0644 \u0646\u06CC\u0633\u062A.", 500);
  let body;
  try {
    body = await req.json();
  } catch {
    return fail("bad_request", "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.", 400);
  }
  const action = String(body?.action || "");
  try {
    if (action === "send") {
      const phone = normalizePhone(body.phone);
      if (!phone) return fail("bad_phone", "\u0634\u0645\u0627\u0631\u0647\u200C\u06CC \u0645\u0648\u0628\u0627\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A. \u0645\u062B\u0644 \u06F0\u06F9\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.", 400);
      if (!devMode() && !smsConfigured()) {
        return fail("sms_unavailable", "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u0647\u0646\u0648\u0632 \u0641\u0639\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0639\u062F\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 503);
      }
      const code = randomCode();
      const r = await rpc("otp_issue", { p_phone: phone, p_hash: await codeHash(phone, code), p_ttl: 120 });
      if (!r?.ok) {
        if (r?.error === "too_soon") return fail("too_soon", "\u0644\u0637\u0641\u0627\u064B \u06A9\u0645\u06CC \u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 429, { retry_in: r.retry_in });
        if (r?.error === "limit") return fail("limit", "\u062A\u0639\u062F\u0627\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0632\u06CC\u0627\u062F \u0628\u0648\u062F\u0647 \u0627\u0633\u062A. \u0628\u0639\u062F\u0627\u064B \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 429, { retry_in: r.retry_in });
        return fail("bad_phone", "\u0634\u0645\u0627\u0631\u0647\u200C\u06CC \u0645\u0648\u0628\u0627\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.", 400);
      }
      if (devMode()) {
        return json({ ok: true, expires_in: r.expires_in, resend_in: r.resend_in, dev_code: code });
      }
      try {
        await sendSms(phone, code);
      } catch (e) {
        console.error("sms failed:", e.message);
        return fail("sms_failed", "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F. \u0686\u0646\u062F \u0644\u062D\u0638\u0647 \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 502);
      }
      return json({ ok: true, expires_in: r.expires_in, resend_in: r.resend_in });
    }
    if (action === "verify") {
      const phone = normalizePhone(body.phone);
      const code = String(body.code ?? "").replace(/[۰-۹]/g, (d) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(d))).trim();
      if (!phone || !/^\d{5}$/.test(code)) return fail("bad_request", "\u06A9\u062F \u0628\u0627\u06CC\u062F \u06F5 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F.", 400);
      const name = String(body.name ?? "").replace(/\s+/g, " ").trim();
      if (name.length < 2 || name.length > 60) return fail("bad_name", "\u0646\u0627\u0645 \u0648 \u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F (\u062D\u062F\u0627\u0642\u0644 \u06F2 \u062D\u0631\u0641).", 400);
      const token = randomToken();
      const r = await rpc("otp_verify", { p_phone: phone, p_hash: await codeHash(phone, code), p_token_hash: await sha256Hex(token), p_name: name });
      if (r?.ok) return json({ ok: true, token, phone: r.phone, name: r.name ?? name, created: !!r.created });
      if (r?.error === "bad_name") return fail("bad_name", "\u0646\u0627\u0645 \u0648 \u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F (\u062D\u062F\u0627\u0642\u0644 \u06F2 \u062D\u0631\u0641).", 400);
      if (r?.error === "wrong") return fail("wrong", "\u06A9\u062F \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.", 400, { attempts_left: r.attempts_left });
      if (r?.error === "locked") return fail("locked", "\u062A\u0639\u062F\u0627\u062F \u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0632\u06CC\u0627\u062F \u0628\u0648\u062F. \u06CC\u06A9 \u06A9\u062F \u062C\u062F\u06CC\u062F \u0628\u06AF\u06CC\u0631\u06CC\u062F.", 429);
      return fail("expired", "\u06A9\u062F \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u06CC\u06A9 \u06A9\u062F \u062C\u062F\u06CC\u062F \u0628\u06AF\u06CC\u0631\u06CC\u062F.", 400);
    }
    if (action === "email_send") {
      const email = normalizeEmail(body.email);
      if (!email) return fail("bad_email", "\u0627\u06CC\u0645\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A. \u0645\u062B\u0644 name@example.com \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.", 400);
      if (!devMode() && !emailConfigured()) {
        return fail("email_unavailable", "\u0627\u0631\u0633\u0627\u0644 \u0627\u06CC\u0645\u06CC\u0644 \u0647\u0646\u0648\u0632 \u0641\u0639\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0639\u062F\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 503);
      }
      const code = randomCode();
      const r = await rpc("email_otp_issue", { p_email: email, p_hash: await emailCodeHash(email, code), p_ttl: 120 });
      if (!r?.ok) {
        if (r?.error === "too_soon") return fail("too_soon", "\u0644\u0637\u0641\u0627\u064B \u06A9\u0645\u06CC \u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 429, { retry_in: r.retry_in });
        if (r?.error === "limit") return fail("limit", "\u062A\u0639\u062F\u0627\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0632\u06CC\u0627\u062F \u0628\u0648\u062F\u0647 \u0627\u0633\u062A. \u0628\u0639\u062F\u0627\u064B \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 429, { retry_in: r.retry_in });
        return fail("bad_email", "\u0627\u06CC\u0645\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.", 400);
      }
      if (devMode()) return json({ ok: true, expires_in: r.expires_in, resend_in: r.resend_in, dev_code: code });
      try {
        await sendEmail(email, code);
      } catch (e) {
        console.error("email failed:", e.message);
        return fail("email_failed", "\u0627\u0631\u0633\u0627\u0644 \u0627\u06CC\u0645\u06CC\u0644 \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F. \u0686\u0646\u062F \u0644\u062D\u0638\u0647 \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 502);
      }
      return json({ ok: true, expires_in: r.expires_in, resend_in: r.resend_in });
    }
    if (action === "email_verify") {
      const email = normalizeEmail(body.email);
      const code = toLatin(String(body.code ?? "")).trim();
      const name = String(body.name ?? "").replace(/\s+/g, " ").trim();
      if (!email || !/^\d{5}$/.test(code)) return fail("bad_request", "\u06A9\u062F \u0628\u0627\u06CC\u062F \u06F5 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F.", 400);
      const token = randomToken();
      const r = await rpc("email_otp_verify", { p_email: email, p_hash: await emailCodeHash(email, code), p_token_hash: await sha256Hex(token), p_name: name || null });
      if (r?.ok) return json({ ok: true, token, email: r.email, name: r.name ?? null, avatar: r.avatar ?? null, created: !!r.created });
      if (r?.error === "bad_name") return fail("bad_name", "\u0646\u0627\u0645 \u0648 \u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F (\u062D\u062F\u0627\u0642\u0644 \u06F2 \u062D\u0631\u0641).", 400);
      if (r?.error === "wrong") return fail("wrong", "\u06A9\u062F \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.", 400, { attempts_left: r.attempts_left });
      if (r?.error === "locked") return fail("locked", "\u062A\u0639\u062F\u0627\u062F \u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0632\u06CC\u0627\u062F \u0628\u0648\u062F. \u06CC\u06A9 \u06A9\u062F \u062C\u062F\u06CC\u062F \u0628\u06AF\u06CC\u0631\u06CC\u062F.", 429);
      return fail("expired", "\u06A9\u062F \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u06CC\u06A9 \u06A9\u062F \u062C\u062F\u06CC\u062F \u0628\u06AF\u06CC\u0631\u06CC\u062F.", 400);
    }
    if (action === "profile_update") {
      const token = String(body.token || "");
      if (!/^[0-9a-f]{64}$/.test(token)) return fail("no_session", "\u0646\u0634\u0633\u062A \u0634\u0645\u0627 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u062F\u0648\u0628\u0627\u0631\u0647 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F.", 401);
      const name = String(body.name ?? "").replace(/\s+/g, " ").trim();
      const avatar = body.avatar == null ? null : String(body.avatar);
      const r = await rpc("profile_update", { p_token_hash: await sha256Hex(token), p_name: name, p_avatar: avatar });
      if (r?.ok) return json({ ok: true, name: r.name, avatar: r.avatar ?? null });
      if (r?.error === "bad_name") return fail("bad_name", "\u0646\u0627\u0645 \u0648 \u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F (\u062D\u062F\u0627\u0642\u0644 \u06F2 \u062D\u0631\u0641).", 400);
      if (r?.error === "no_session") return fail("no_session", "\u0646\u0634\u0633\u062A \u0634\u0645\u0627 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u062F\u0648\u0628\u0627\u0631\u0647 \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F.", 401);
      return fail("bad_request", "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.", 400);
    }
    if (action === "me") {
      const token = String(body.token || "");
      if (!/^[0-9a-f]{64}$/.test(token)) return json({ ok: false, error: "no_session" }, 200);
      const info = await rpc("session_info", { p_token_hash: await sha256Hex(token) });
      return json(info && (info.phone || info.email) ? { ok: true, phone: info.phone ?? null, email: info.email ?? null, name: info.name ?? null, avatar: info.avatar ?? null } : { ok: false, error: "no_session" });
    }
    if (action === "logout") {
      const token = String(body.token || "");
      if (/^[0-9a-f]{64}$/.test(token)) await rpc("session_end", { p_token_hash: await sha256Hex(token) });
      return json({ ok: true });
    }
    return fail("bad_request", "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.", 400);
  } catch (e) {
    console.error("auth-otp error:", e.message);
    return fail("server", "\u062E\u0637\u0627\u06CC\u06CC \u062F\u0631 \u0633\u0631\u0648\u0631 \u0631\u062E \u062F\u0627\u062F. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.", 500);
  }
});
