#!/usr/bin/env node
// ورود یک کتاب درسی (PDF) به پازمونک: هر صفحه به‌صورت تصویر به Gemini داده می‌شود و متن مرتب (با فرمول و توضیح شکل‌ها) در دیتابیس ذخیره می‌شود.
// ادامه‌پذیر است: اگر وسط کار قطع شد، دوباره اجرا کنید؛ فقط صفحه‌های مانده انجام می‌شوند.
// استفاده (از طریق bookingest.sh):
//   node ingest.js book.pdf --slug math7 --title "ریاضی هفتم" --grade هفتم --subject ریاضی --offset 9 --toc 4
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const argv = process.argv.slice(2);
const file = argv[0];
const opt = (k, d) => { const i = argv.indexOf('--' + k); return i > 0 && argv[i + 1] !== undefined ? argv[i + 1] : d; };
const slug = opt('slug', '');
const title = opt('title', '');
const grade = opt('grade', '');
const subject = opt('subject', '');
const offset = parseInt(opt('offset', '0'), 10) || 0;          // شماره‌ی چاپی = شماره‌ی صفحه‌ی PDF − ۱ − offset
const tocPages = String(opt('toc', '')).split(',').map((x) => parseInt(x, 10)).filter((x) => x > 0);
const MODEL = opt('model', 'gemini-2.5-flash');
const FIRST = parseInt(opt('first', '1'), 10) || 1;
const LAST = parseInt(opt('last', '100000'), 10) || 100000;
const CONC = Math.max(1, Math.min(6, parseInt(opt('conc', '3'), 10) || 3));

const RELAY = (process.env.AI_RELAY || '').trim();
const RELAY_KEY = process.env.AI_RELAY_KEY || '';
const PROJECT = (process.env.GOOGLE_PROJECT || '').trim();
const SERVICE_KEY = process.env.SERVICE_KEY || '';
const API = (process.env.API_URL || 'http://127.0.0.1:' + (process.env.PORT || '8787')).replace(/\/+$/, '');

function die(m) { console.error('❌ ' + m); process.exit(1); }
if (!file || !fs.existsSync(file)) die('فایل PDF پیدا نشد: ' + file);
if (!/^[a-z0-9_-]{1,40}$/.test(slug)) die('--slug باید فقط حرف انگلیسی کوچک، عدد، - یا _ باشد (مثلاً math7).');
if (!title) die('--title لازم است (مثلاً "ریاضی هفتم").');
if (!SERVICE_KEY) die('SERVICE_KEY در تنظیمات سرور پیدا نشد.');
if (!RELAY || !PROJECT) die('تنظیم Gemini (AI_RELAY و GOOGLE_PROJECT) در تنظیمات سرور پیدا نشد.');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function rpc(name, args) {
  const r = await fetch(API + '/rest/v1/rpc/' + name, {
    method: 'POST',
    headers: { 'content-type': 'application/json', apikey: SERVICE_KEY, authorization: 'Bearer ' + SERVICE_KEY },
    body: JSON.stringify(args),
    signal: AbortSignal.timeout(30000),
  });
  const t = await r.text();
  if (!r.ok) throw new Error('rpc ' + name + ' ' + r.status + ' ' + t.slice(0, 200));
  return t ? JSON.parse(t) : null;
}

const PROMPT = [
  'این تصویر یک صفحه از کتاب درسی «' + title + '» (آموزش و پرورش ایران) است. آن را مثل یک معلم دقیق بخوان و تمام محتوایش را به متن مرتب تبدیل کن.',
  'قواعد:',
  '- متن فارسی را دقیق و کامل و به ترتیب خواندن (بالا به پایین، راست به چپ) بنویس. هیچ چیز را خلاصه یا حذف نکن و چیزی از خودت اضافه نکن.',
  '- عنوان‌های بزرگ را با ## و عنوان‌های کوچک را با ### بنویس. بخش‌هایی مثل «فعالیت»، «کار در کلاس»، «تمرین»، «مثال»، «بیشتر بدانید» را با همین نام و با ### بنویس. شماره‌ی هر سؤال و هر مرحله را نگه دار.',
  '- فرمول‌ها و عبارت‌های ریاضی و علمی را با LaTeX درون \\( ... \\) (یا \\[ ... \\] برای فرمول جدا) بنویس. عددها را همان‌طور که در صفحه هست بنویس.',
  '- جدول‌ها را با Markdown بنویس.',
  '- برای هر شکل، نمودار، محور عددی، عکس یا تصویر مهم یک خط به این شکل بنویس: [شکل: توضیح کوتاه و دقیق آنچه دیده می‌شود، شامل عددها و برچسب‌های روی آن]',
  '- شماره‌ی صفحه‌ی چاپی (بالا یا پایین صفحه) را در خط آخر به این شکل بنویس: [شماره‌ی صفحه: N]. اگر نبود ننویس.',
  '- فقط خود محتوای صفحه را بنویس، بدون هیچ مقدمه یا توضیح.',
].join('\n');

async function gemini(jpgPath) {
  const b64 = fs.readFileSync(jpgPath).toString('base64');
  const url = 'https://aiplatform.googleapis.com/v1/projects/' + encodeURIComponent(PROJECT) + '/locations/global/publishers/google/models/' + encodeURIComponent(MODEL) + ':generateContent';
  const gen = { temperature: 0.1, maxOutputTokens: 8192 };
  if (/^gemini-2\.5/.test(MODEL)) gen.thinkingConfig = { thinkingBudget: 0 };
  const r = await fetch(RELAY, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-relay-target': url, 'x-relay-key': RELAY_KEY, 'x-relay-gauth': '1' },
    body: JSON.stringify({ contents: [{ role: 'user', parts: [{ inlineData: { mimeType: 'image/jpeg', data: b64 } }, { text: PROMPT }] }], generationConfig: gen }),
    signal: AbortSignal.timeout(150000),
  });
  const t = await r.text();
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + t.replace(/\s+/g, ' ').slice(0, 160));
  const j = JSON.parse(t);
  const c = j && j.candidates && j.candidates[0];
  const text = ((c && c.content && c.content.parts) || []).map((p) => (typeof p.text === 'string' ? p.text : '')).join('').trim();
  const fr = String((c && c.finishReason) || '');
  if (!text) throw new Error('پاسخ خالی' + (fr ? ' (' + fr + ')' : ''));
  if (fr === 'MAX_TOKENS') throw new Error('پاسخ ناقص (MAX_TOKENS)');
  return text;
}

async function main() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pzbook-'));
  console.log('در حال تبدیل صفحه‌های PDF به تصویر...');
  const rr = cp.spawnSync('pdftoppm', ['-r', '110', '-jpeg', '-jpegopt', 'quality=78', '-f', String(FIRST), '-l', String(Math.min(LAST, 100000)), file, path.join(tmp, 'p')], { encoding: 'utf8' });
  if (rr.error || rr.status !== 0) die('pdftoppm اجرا نشد: ' + ((rr.error && rr.error.message) || rr.stderr || '').slice(0, 200));
  const imgs = fs.readdirSync(tmp).filter((f) => /^p-\d+\.jpg$/.test(f)).sort();
  if (!imgs.length) die('هیچ صفحه‌ای تبدیل نشد.');
  const pages = imgs.map((f) => ({ n: parseInt(f.slice(2, -4), 10), f: path.join(tmp, f) }));

  await rpc('book_upsert', { p_slug: slug, p_title: title, p_grade: grade, p_subject: subject, p_toc: '' });
  const done = new Set(await rpc('book_done', { p_slug: slug }));
  const todo = pages.filter((p) => !done.has(p.n));
  console.log('کل صفحه‌ها: ' + pages.length + ' | قبلاً انجام شده: ' + (pages.length - todo.length) + ' | مانده: ' + todo.length + ' | مدل: ' + MODEL);

  let ok = 0, fail = 0, mism = 0, idx = 0;
  const failed = [];
  const t0 = Date.now();
  const worker = async () => {
    for (;;) {
      const p = todo[idx++];
      if (!p) return;
      let text = '', err = '';
      for (let a = 1; a <= 4; a++) {
        try { text = await gemini(p.f); err = ''; break; } catch (e) { err = String(e && e.message || e); await sleep(1500 * a); }
      }
      if (!text) { fail++; failed.push(p.n); console.log('  ❌ صفحه‌ی PDF ' + p.n + ': ' + err); continue; }
      let printed = p.n - 1 - offset;
      if (printed < 1) printed = null;
      const m = /\[شماره‌ی صفحه:\s*([0-9۰-۹٠-٩]+)\s*\]\s*$/.exec(text);
      if (m) {
        const read = parseInt(String(m[1]).replace(/[۰-۹]/g, (c) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g, (c) => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)), 10);
        if (printed !== null && read !== printed) { mism++; console.log('  ⚠️ صفحه‌ی PDF ' + p.n + ': شماره‌ی چاپی محاسبه‌شده ' + printed + ' ولی روی صفحه ' + read + ' خوانده شد'); }
        text = text.slice(0, m.index).trim();
      }
      try { await rpc('book_save_page', { p_slug: slug, p_pdf_page: p.n, p_printed: printed, p_body: text || '(صفحه‌ی بدون متن)' }); ok++; }
      catch (e) { fail++; failed.push(p.n); console.log('  ❌ ذخیره‌ی صفحه‌ی ' + p.n + ': ' + String(e.message || e).slice(0, 120)); continue; }
      if ((ok + fail) % 10 === 0 || ok + fail === todo.length) console.log('  ... ' + (ok + fail) + ' از ' + todo.length + ' (' + Math.round((Date.now() - t0) / 1000) + ' ثانیه)');
    }
  };
  await Promise.all(Array.from({ length: CONC }, worker));

  if (tocPages.length) {
    let toc = '';
    for (const n of tocPages) { try { toc += (await rpc('book_page_text', { p_slug: slug, p_pdf_page: n })) + '\n'; } catch (e) { /* ignore */ } }
    toc = toc.trim().slice(0, 6000);
    if (toc) { await rpc('book_upsert', { p_slug: slug, p_title: title, p_grade: grade, p_subject: subject, p_toc: toc }); console.log('فهرست کتاب ذخیره شد (' + toc.length + ' حرف).'); }
    else console.log('⚠️ فهرست پیدا نشد؛ شماره‌ی صفحه‌ی فهرست را بررسی کنید.');
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('\nتمام شد: ' + ok + ' صفحه ذخیره شد، ' + fail + ' ناموفق، ' + mism + ' ناهمخوانی شماره‌ی صفحه.');
  if (failed.length) console.log('صفحه‌های ناموفق (دوباره همین دستور را بزنید تا فقط همین‌ها انجام شود): ' + failed.sort((a, b) => a - b).join(', '));
  try {
    const s = await rpc('book_get', { p_slug: slug, p_from: 21, p_to: 21 });
    if (s && s[0]) console.log('\n--- نمونه: صفحه‌ی ۲۱ ---\n' + s[0].body.slice(0, 900));
  } catch (e) { /* ignore */ }
  process.exit(fail ? 2 : 0);
}
main().catch((e) => die(String(e && e.stack || e).slice(0, 400)));
