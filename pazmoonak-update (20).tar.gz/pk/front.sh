#!/usr/bin/env bash
# راه‌اندازی سایت (فرانت‌اند) روی همین سرور. با root اجرا شود:  bash front.sh pazmoonak.com
# چندبار اجرا کردنش بی‌خطر است. به API و داده‌ها دست نمی‌زند.
set -euo pipefail
DOMAIN="${1:-pazmoonak.com}"
SRC="$(cd "$(dirname "$0")" && pwd)"
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
echo "== [1/3] ابزار به‌روزرسانی سایت"
install -m 755 "$SRC/front-sync.sh" /usr/local/bin/pz-front
echo "== [2/3] تنظیم nginx برای ${DOMAIN}"
sed "s/__DOMAIN__/${DOMAIN}/g" "$SRC/nginx-front.conf" > /etc/nginx/sites-available/pazmoonak-front
ln -sf /etc/nginx/sites-available/pazmoonak-front /etc/nginx/sites-enabled/pazmoonak-front
mkdir -p /var/www/pazmoonak
nginx -t
echo "== [3/3] دریافت فایل‌های سایت"
/usr/local/bin/pz-front
systemctl reload nginx
echo
echo "تست داخلی:"
curl -s -o /dev/null -w "  کد پاسخ: %{http_code}  اندازه: %{size_download}\n" -H "Host: ${DOMAIN}" http://127.0.0.1/
echo "تمام شد ✅  (هنوز DNS را عوض نکرده‌اید؛ سایت فعلی دست‌نخورده است)"
