#!/usr/bin/env bash
# بررسی اینکه سرور به واسطه‌ی Cloudflare می‌رسد و کلیدش درست است. با root اجرا شود:  bash testrelay.sh
set -uo pipefail
ENV_FILE=/etc/pazmoonak/env
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
RELAY="$(sed -n 's/^AI_RELAY=//p' "$ENV_FILE" | tail -1)"
KEY="$(sed -n 's/^AI_RELAY_KEY=//p' "$ENV_FILE" | tail -1)"
[ -n "$RELAY" ] && [ -n "$KEY" ] || { echo "❌ هنوز AI_RELAY و AI_RELAY_KEY را وارد نکرده‌اید."; exit 1; }
for T in https://api.perplexity.ai/ https://generativelanguage.googleapis.com/ https://api.resend.com/; do
  CODE="$(curl -s -o /dev/null -m 20 -w '%{http_code}' -H "x-relay-key: $KEY" -H "x-relay-target: $T" "$RELAY")"
  case "$CODE" in
    000) echo "❌ $T  ← سرور به واسطه نرسید (آدرس یا اینترنت)";;
    403) echo "❌ $T  ← واسطه جواب داد ولی کلیدش (RELAY_KEY) با سرور فرق دارد";;
    5??) echo "⚠️ $T  ← خطای $CODE از طرف مقصد";;
    *)   echo "✅ $T  ← کار می‌کند (کد $CODE)";;
  esac
done
