#!/usr/bin/env bash
# ذخیره‌ی یک کلید محرمانه در تنظیمات سرور، بدون نمایش آن روی صفحه و بدون ماندن در تاریخچه‌ی دستورها.
# استفاده (با root):   bash setkey.sh GEMINI_API_KEY
set -euo pipefail
ENV_FILE=/etc/pazmoonak/env
[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }
[ -f "$ENV_FILE" ] || { echo "فایل تنظیمات پیدا نشد: $ENV_FILE"; exit 1; }
NAME="${1:-}"
case "$NAME" in
  GEMINI_API_KEY|PERPLEXITY_API_KEY|DEEPSEEK_API_KEY|RESEND_API_KEY|AI_RELAY|AI_RELAY_KEY) ;;
  *) echo "نام نامعتبر است. نام‌های مجاز: GEMINI_API_KEY PERPLEXITY_API_KEY DEEPSEEK_API_KEY RESEND_API_KEY AI_RELAY AI_RELAY_KEY"; exit 1;;
esac
read -r -s -p "مقدار $NAME را بچسبانید و Enter بزنید (روی صفحه دیده نمی‌شود): " VAL
echo
VAL="$(printf '%s' "$VAL" | tr -d '\r\n')"
[ -n "$VAL" ] || { echo "چیزی وارد نشد؛ تغییری داده نشد."; exit 1; }
case "$VAL" in
  *[[:space:]]*|*\"*|*\'*|*\\*) echo "مقدار نباید فاصله یا نقل‌قول داشته باشد؛ احتمالاً چیز اضافه‌ای همراه کپی شده. دوباره امتحان کنید."; exit 1;;
esac
TMP="$(mktemp)"
grep -v "^${NAME}=" "$ENV_FILE" > "$TMP" || true
printf '%s=%s\n' "$NAME" "$VAL" >> "$TMP"
cat "$TMP" > "$ENV_FILE"
rm -f "$TMP"
chown root:pazmoonak "$ENV_FILE"; chmod 640 "$ENV_FILE"
systemctl restart pazmoonak
sleep 2
echo "ذخیره شد و سرویس دوباره راه‌اندازی شد ✅  ($NAME با ${#VAL} حرف)"
