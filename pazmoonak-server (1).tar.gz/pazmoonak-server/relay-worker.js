// Cloudflare Worker: واسطه‌ی «سرور به سرور» برای سرویس‌های هوش مصنوعی خارجی.
// فقط سرور پازمونک از آن استفاده می‌کند (با کلید مخفی). کاربران سایت هرگز به آن وصل نمی‌شوند.
// در Cloudflare یک متغیر مخفی به اسم RELAY_KEY بسازید (همان مقدار AI_RELAY_KEY در فایل env سرور).
const ALLOWED = /(^|\.)(googleapis\.com|api\.deepseek\.com|api\.perplexity\.ai|openai\.com|anthropic\.com)$/i;

export default {
  async fetch(request, env) {
    if (request.method !== "POST" && request.method !== "GET") return new Response("method", { status: 405 });
    const key = request.headers.get("x-relay-key") || "";
    if (!env.RELAY_KEY || key !== env.RELAY_KEY) return new Response("forbidden", { status: 403 });
    let target;
    try { target = new URL(request.headers.get("x-relay-target") || ""); } catch { return new Response("bad target", { status: 400 }); }
    if (target.protocol !== "https:" || !ALLOWED.test(target.hostname)) return new Response("host not allowed", { status: 403 });
    const headers = new Headers(request.headers);
    for (const h of ["x-relay-key", "x-relay-target", "host", "cf-connecting-ip", "x-forwarded-for"]) headers.delete(h);
    return fetch(target.toString(), { method: request.method, headers, body: request.method === "GET" ? undefined : request.body });
  },
};
