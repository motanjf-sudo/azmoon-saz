#!/usr/bin/env bash
# نصب بک‌اند پازمونک روی Ubuntu 24.04 (یا 22.04). با دسترسی root اجرا شود:
#   bash install.sh api.pazmoonak.com
# چندبار اجرا کردنش بی‌خطر است (داده‌ها و رمزها پاک نمی‌شوند).
set -euo pipefail

DOMAIN="${1:-api.pazmoonak.com}"
SRC="$(cd "$(dirname "$0")" && pwd)"
ENV_FILE=/etc/pazmoonak/env
APP=/opt/pazmoonak

[ "$(id -u)" = "0" ] || { echo "این اسکریپت باید با کاربر root اجرا شود."; exit 1; }

echo "== [1/8] نصب بسته‌ها"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y postgresql nginx certbot python3-certbot-nginx ufw fail2ban nodejs curl ca-certificates

echo "== [2/8] ساخت کاربر و پوشه‌ها"
id pazmoonak >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin pazmoonak
mkdir -p "$APP" /etc/pazmoonak
rm -rf "$APP/fn" "$APP/node_modules"
cp -r "$SRC/server.js" "$SRC/deno-shim.js" "$SRC/package.json" "$SRC/fn" "$SRC/node_modules" "$APP/"
chown -R root:pazmoonak "$APP"
chmod -R g+rX,o-rwx "$APP"

echo "== [3/8] تنظیمات و رمزها"
if [ ! -f "$ENV_FILE" ]; then
  DB_PASS="$(openssl rand -hex 24)"
  cat > "$ENV_FILE" <<EOF
DATABASE_URL=postgres://api:${DB_PASS}@127.0.0.1:5432/pazmoonak
SERVICE_KEY=$(openssl rand -hex 32)
OTP_PEPPER=$(openssl rand -hex 24)
PORT=8787
HOST=127.0.0.1
# حالت آزمایشی: 1 یعنی کد پیامک نمی‌رود و در پاسخ برمی‌گردد. در سایت واقعی همیشه 0 باشد.
OTP_DEV_MODE=0
# پیامک: smsir را بنویسید و دو مقدار پایین را پر کنید
SMS_PROVIDER=
SMSIR_API_KEY=
SMSIR_TEMPLATE_ID=
SMSIR_PARAM_NAME=Code
# هوش مصنوعی (هر کدام را که دارید پر کنید)
DEEPSEEK_API_KEY=
GEMINI_API_KEY=
PERPLEXITY_API_KEY=
# واسطه‌ی خارج از ایران برای سرویس‌هایی که IP ایران را می‌بندند (اختیاری)
AI_RELAY=
AI_RELAY_KEY=
EOF
  chown root:pazmoonak "$ENV_FILE"; chmod 640 "$ENV_FILE"
  echo "فایل تنظیمات ساخته شد: $ENV_FILE"
else
  echo "فایل تنظیمات از قبل هست و دست نخورد."
  DB_PASS="$(sed -n 's#^DATABASE_URL=postgres://api:\([^@]*\)@.*#\1#p' "$ENV_FILE")"
fi

echo "== [4/8] ساخت دیتابیس"
systemctl enable --now postgresql
mkdir -p /tmp/pz && cp "$SRC/db/init-roles.sql" "$SRC/db/schema.sql" /tmp/pz/ && chmod -R a+rX /tmp/pz
if ! su postgres -c "psql -tAc \"select 1 from pg_database where datname='pazmoonak'\"" | grep -q 1; then
  su postgres -c "createdb pazmoonak"
fi
su postgres -c "psql -q -v ON_ERROR_STOP=1 -d pazmoonak -f /tmp/pz/init-roles.sql -f /tmp/pz/schema.sql"
su postgres -c "psql -q -v ON_ERROR_STOP=1 -d pazmoonak" <<SQL
do \$\$ begin
  if not exists (select 1 from pg_roles where rolname = 'api') then create role api login noinherit; end if;
end \$\$;
alter role api password '${DB_PASS}';
grant anon, authenticated, service_role to api;
SQL
rm -rf /tmp/pz

echo "== [5/8] سرویس برنامه"
cp "$SRC/pazmoonak.service" /etc/systemd/system/pazmoonak.service
systemctl daemon-reload
systemctl enable pazmoonak
systemctl restart pazmoonak
sleep 2
if curl -fsS http://127.0.0.1:8787/healthz >/dev/null; then echo "برنامه بالا آمد."; else echo "هشدار: برنامه بالا نیامد. دستور: journalctl -u pazmoonak -n 50"; fi

echo "== [6/8] وب‌سرور (nginx)"
cp "$SRC/nginx-proxy.inc" /etc/nginx/pazmoonak-proxy.inc
sed "s/__DOMAIN__/${DOMAIN}/g" "$SRC/nginx-api.conf" > /etc/nginx/sites-available/pazmoonak-api
ln -sf /etc/nginx/sites-available/pazmoonak-api /etc/nginx/sites-enabled/pazmoonak-api
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable --now nginx
systemctl reload nginx

echo "== [7/8] فایروال و امنیت"
ufw allow 22/tcp >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null
systemctl enable --now fail2ban

echo "== [8/8] پشتیبان روزانه"
cp "$SRC/backup.sh" /usr/local/bin/pazmoonak-backup.sh
chmod 755 /usr/local/bin/pazmoonak-backup.sh
echo "30 3 * * * root /usr/local/bin/pazmoonak-backup.sh >> /var/log/pazmoonak-backup.log 2>&1" > /etc/cron.d/pazmoonak
chmod 644 /etc/cron.d/pazmoonak

echo
echo "گواهی HTTPS (باید رکورد A دامنه‌ی ${DOMAIN} به IP همین سرور اشاره کند):"
if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect; then
  echo "HTTPS فعال شد."
else
  echo "هشدار: گرفتن گواهی HTTPS موفق نبود. رکورد DNS را بررسی کنید و بعداً این دستور را بزنید:"
  echo "  certbot --nginx -d ${DOMAIN} --agree-tos --register-unsafely-without-email --redirect"
fi

echo
echo "تمام شد. آدرس API:  https://${DOMAIN}"
echo "تنظیم پیامک و هوش مصنوعی:  nano ${ENV_FILE}   سپس:  systemctl restart pazmoonak"
