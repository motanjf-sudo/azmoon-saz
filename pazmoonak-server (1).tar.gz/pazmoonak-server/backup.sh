#!/bin/sh
# پشتیبان روزانه‌ی دیتابیس؛ ۱۴ نسخه‌ی آخر نگه داشته می‌شود
set -e
DIR=/var/backups/pazmoonak
mkdir -p "$DIR"
F="$DIR/pazmoonak-$(date +%Y%m%d-%H%M).sql.gz"
sudo -u postgres pg_dump --no-owner pazmoonak | gzip -9 > "$F"
chmod 600 "$F"
ls -1t "$DIR"/pazmoonak-*.sql.gz | tail -n +15 | xargs -r rm -f
echo "backup: $F ($(du -h "$F" | cut -f1))"
