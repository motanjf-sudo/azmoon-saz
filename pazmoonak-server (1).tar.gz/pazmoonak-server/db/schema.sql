-- آزمون‌ساز: ساختار پایگاه‌داده
-- این فایل را در Supabase > SQL Editor اجرا کنید.
-- چندبار اجرا کردنش بی‌خطر است (اگر قبلاً اجرا کرده‌اید، فقط تابع‌ها به‌روز می‌شوند و داده‌ها پاک نمی‌شوند).
--
-- نوع سؤال‌ها (فیلد type در هر سؤال):
--   mcq   : چندگزینه‌ای (۲ تا ۸ گزینه)
--   tf    : درست/نادرست (دقیقاً ۲ گزینه)
-- آزمون‌های قدیمی که type ندارند، چندگزینه‌ای حساب می‌شوند.

create table if not exists public.quizzes (
  id          text primary key,
  title       text not null check (char_length(title) between 1 and 200),
  description text not null default '' check (char_length(description) <= 2000),
  questions   jsonb not null,            -- [{ "type":"mcq", "text":"...", "options":["..",".."], "correct":0 }]
  admin_hash  text not null,             -- هش SHA-256 کلید مدیریت
  created_at  timestamptz not null default now()
);

create table if not exists public.submissions (
  id         bigserial primary key,
  quiz_id    text not null references public.quizzes(id) on delete cascade,
  name       text not null check (char_length(name) between 1 and 100),
  answers    jsonb not null,
  score      int not null,
  total      int not null,
  created_at timestamptz not null default now()
);

create index if not exists submissions_quiz_idx on public.submissions(quiz_id);

-- دسترسی مستقیم به جدول‌ها بسته است؛ فقط از طریق تابع‌های پایین.
alter table public.quizzes     enable row level security;
alter table public.submissions enable row level security;

-- بررسی سؤال‌ها (مشترک بین ساخت و ویرایش)
create or replace function public.validate_questions(p_questions jsonb)
returns void
language plpgsql set search_path = public as $$
declare
  q jsonb;
  qtype text;
  n int;
begin
  if p_questions is null or jsonb_typeof(p_questions) <> 'array' or jsonb_array_length(p_questions) = 0
     or jsonb_array_length(p_questions) > 100 then
    raise exception 'تعداد سؤال‌ها نامعتبر است';
  end if;
  for q in select * from jsonb_array_elements(p_questions) loop
    if jsonb_typeof(q) <> 'object' then
      raise exception 'یکی از سؤال‌ها نامعتبر است';
    end if;
    qtype := coalesce(q->>'type', 'mcq');
    if qtype not in ('mcq', 'tf') then
      raise exception 'نوع سؤال نامعتبر است';
    end if;
    if jsonb_typeof(q->'text') <> 'string' or char_length(trim(q->>'text')) = 0
       or char_length(q->>'text') > 500 then
      raise exception 'متن یکی از سؤال‌ها نامعتبر است';
    end if;
    if jsonb_typeof(q->'options') <> 'array' then
      raise exception 'گزینه‌های یکی از سؤال‌ها نامعتبر است';
    end if;
    n := jsonb_array_length(q->'options');
    if n < 2 or n > 8 then
      raise exception 'تعداد گزینه‌های یکی از سؤال‌ها نامعتبر است';
    end if;
    if exists (
      select 1 from jsonb_array_elements(q->'options') o
      where jsonb_typeof(o) <> 'string' or char_length(trim(o #>> '{}')) = 0 or char_length(o #>> '{}') > 300
    ) then
      raise exception 'گزینه‌ی یکی از سؤال‌ها نامعتبر است';
    end if;
    if qtype = 'tf' and n <> 2 then
      raise exception 'سؤال درست/نادرست باید دقیقاً دو گزینه داشته باشد';
    end if;
    if jsonb_typeof(q->'correct') <> 'number'
       or (q->>'correct') !~ '^[0-9]+$'
       or (q->>'correct')::int >= n then
      raise exception 'پاسخ درست یکی از سؤال‌ها نامعتبر است';
    end if;
  end loop;
end $$;

-- نسخه‌های قدیمیِ بدون توکن حذف می‌شوند (ساخت آزمون، دیدن آزمون و ثبت پاسخ فقط با نشست معتبر)
drop function if exists public.create_quiz(text,text,jsonb,text);
drop function if exists public.get_quiz(text);
drop function if exists public.submit_quiz(text,text,jsonb);

-- ساخت آزمون
create or replace function public.create_quiz(
  p_title text, p_description text, p_questions jsonb, p_secret text, p_token text
) returns text
language plpgsql security definer set search_path = public as $$
declare
  new_id text;
begin
  if public.session_uid(p_token) is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  if p_title is null or char_length(trim(p_title)) = 0 or char_length(p_title) > 200 then
    raise exception 'عنوان نامعتبر است';
  end if;
  if p_description is not null and char_length(p_description) > 2000 then
    raise exception 'توضیح خیلی بلند است';
  end if;
  if p_secret is null or char_length(p_secret) < 16 then
    raise exception 'کلید مدیریت نامعتبر است';
  end if;
  perform public.validate_questions(p_questions);

  new_id := substr(replace(gen_random_uuid()::text, '-', ''), 1, 8);
  insert into quizzes(id, title, description, questions, admin_hash)
  values (new_id, trim(p_title), coalesce(p_description, ''), p_questions,
          encode(sha256(convert_to(p_secret, 'utf8')), 'hex'));
  return new_id;
end $$;

-- ویرایش آزمون (با کلید مدیریت). اگر آزمون نتیجه دارد، فقط با تأیید صریح انجام می‌شود و همه‌ی نتایج قبلی پاک می‌شوند.
create or replace function public.update_quiz(
  p_id text, p_secret text, p_title text, p_description text, p_questions jsonb,
  p_confirm_clear boolean default false
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  qz quizzes%rowtype;
  n int;
begin
  select * into qz from quizzes where id = p_id;
  if qz.id is null or qz.admin_hash <> encode(sha256(convert_to(coalesce(p_secret,''), 'utf8')), 'hex') then
    raise exception 'دسترسی نامعتبر';
  end if;
  if p_title is null or char_length(trim(p_title)) = 0 or char_length(p_title) > 200 then
    raise exception 'عنوان نامعتبر است';
  end if;
  if p_description is not null and char_length(p_description) > 2000 then
    raise exception 'توضیح خیلی بلند است';
  end if;
  perform public.validate_questions(p_questions);

  select count(*) into n from submissions where quiz_id = p_id;
  if n > 0 and not coalesce(p_confirm_clear, false) then
    raise exception 'این آزمون نتیجه دارد؛ برای ویرایش باید پاک شدن نتایج را تأیید کنید';
  end if;

  delete from submissions where quiz_id = p_id;
  update quizzes
     set title = trim(p_title), description = coalesce(p_description, ''), questions = p_questions
   where id = p_id;
  return jsonb_build_object('cleared', n);
end $$;

-- گرفتن آزمون برای شرکت‌کننده (بدون پاسخ صحیح)
create or replace function public.get_quiz(p_id text, p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if public.session_uid(p_token) is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  return (select jsonb_build_object(
    'id', id, 'title', title, 'description', description,
    'questions', coalesce((
      select jsonb_agg(
        jsonb_build_object('type', coalesce(t.e->>'type', 'mcq'), 'text', t.e->'text', 'options', t.e->'options')
        order by t.ord
      )
      from jsonb_array_elements(questions) with ordinality as t(e, ord)
    ), '[]'::jsonb)
  ) from quizzes where id = p_id);
end $$;

-- ثبت پاسخ‌ها و محاسبه‌ی نمره در سرور
create or replace function public.submit_quiz(p_id text, p_name text, p_answers jsonb, p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  qs jsonb;
  n int;
  i int;
  s int := 0;
  correct jsonb := '[]'::jsonb;
begin
  if public.session_uid(p_token) is null then
    raise exception 'نشست شما معتبر نیست؛ دوباره وارد شوید.';
  end if;
  select questions into qs from quizzes where id = p_id;
  if qs is null then raise exception 'آزمون پیدا نشد'; end if;
  if p_name is null or char_length(trim(p_name)) = 0 then raise exception 'نام لازم است'; end if;
  if p_answers is null or jsonb_typeof(p_answers) <> 'array' then raise exception 'پاسخ‌ها نامعتبر است'; end if;
  n := jsonb_array_length(qs);
  for i in 0..n-1 loop
    correct := correct || to_jsonb((qs->i->>'correct')::int);
    if jsonb_typeof(p_answers->i) = 'number' and (p_answers->>i) ~ '^[0-9]+$'
       and (p_answers->>i)::int = (qs->i->>'correct')::int then
      s := s + 1;
    end if;
  end loop;
  insert into submissions(quiz_id, name, answers, score, total)
  values (p_id, left(trim(p_name), 100), p_answers, s, n);
  return jsonb_build_object('score', s, 'total', n, 'correct', correct);
end $$;

-- نتایج برای سازنده (با کلید مدیریت)
create or replace function public.get_results(p_id text, p_secret text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  q quizzes%rowtype;
begin
  select * into q from quizzes where id = p_id;
  if q.id is null or q.admin_hash <> encode(sha256(convert_to(coalesce(p_secret,''), 'utf8')), 'hex') then
    raise exception 'دسترسی نامعتبر';
  end if;
  return jsonb_build_object(
    'title', q.title,
    'description', q.description,
    'questions', q.questions,
    'submissions', coalesce((
      select jsonb_agg(jsonb_build_object(
        'name', name, 'score', score, 'total', total, 'answers', answers, 'created_at', created_at
      ) order by created_at desc) from submissions where quiz_id = p_id
    ), '[]'::jsonb)
  );
end $$;

revoke all on function public.create_quiz(text,text,jsonb,text,text) from public;
revoke all on function public.get_quiz(text,text) from public;
revoke all on function public.submit_quiz(text,text,jsonb,text) from public;
revoke all on function public.get_results(text,text) from public;
revoke all on function public.update_quiz(text,text,text,text,jsonb,boolean) from public;
revoke all on function public.validate_questions(jsonb) from public;
grant execute on function public.create_quiz(text,text,jsonb,text,text) to anon, authenticated;
grant execute on function public.get_quiz(text,text) to anon, authenticated;
grant execute on function public.submit_quiz(text,text,jsonb,text) to anon, authenticated;
grant execute on function public.get_results(text,text) to anon, authenticated;
grant execute on function public.update_quiz(text,text,text,text,jsonb,boolean) to anon, authenticated;

-- ============================================================
-- ثبت‌نام و ورود با شماره‌ی موبایل (کد یک‌بارمصرف)
-- این جدول‌ها و تابع‌ها فقط با کلید service_role (از داخل Edge Function auth-otp) قابل استفاده‌اند.
-- ============================================================
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique check (phone ~ '^09[0-9]{9}$'),
  created_at timestamptz not null default now()
);
-- نام و نام خانوادگی (برای حساب‌های قدیمی خالی می‌ماند تا در ورود بعدی پر شود)
alter table public.users add column if not exists name text;

create table if not exists public.auth_otps (
  phone text primary key check (phone ~ '^09[0-9]{9}$'),
  code_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0,
  sent_at timestamptz not null default now(),
  window_start timestamptz not null default now(),
  window_count int not null default 1
);

create table if not exists public.user_sessions (
  token_hash text primary key,
  user_id uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists user_sessions_user_idx on public.user_sessions(user_id);

alter table public.users enable row level security;
alter table public.auth_otps enable row level security;
alter table public.user_sessions enable row level security;

-- ثبت کد جدید برای یک شماره (با محدودیت ارسال)
create or replace function public.otp_issue(p_phone text, p_hash text, p_ttl int default 120)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r auth_otps%rowtype;
  wait_s int;
  cnt int := 1;
  wstart timestamptz := now();
begin
  if p_phone is null or p_phone !~ '^09[0-9]{9}$' then
    return jsonb_build_object('ok', false, 'error', 'bad_phone');
  end if;
  if p_hash is null or char_length(p_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;

  select * into r from auth_otps where phone = p_phone for update;
  if found then
    wait_s := ceil(extract(epoch from (r.sent_at + interval '60 seconds' - now())))::int;
    if wait_s > 0 then
      return jsonb_build_object('ok', false, 'error', 'too_soon', 'retry_in', wait_s);
    end if;
    if r.window_start > now() - interval '1 hour' then
      if r.window_count >= 5 then
        return jsonb_build_object('ok', false, 'error', 'limit',
          'retry_in', ceil(extract(epoch from (r.window_start + interval '1 hour' - now())))::int);
      end if;
      cnt := r.window_count + 1;
      wstart := r.window_start;
    end if;
  end if;

  insert into auth_otps(phone, code_hash, expires_at, attempts, sent_at, window_start, window_count)
  values (p_phone, p_hash, now() + make_interval(secs => greatest(30, least(p_ttl, 600))), 0, now(), wstart, cnt)
  on conflict (phone) do update set
    code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0,
    sent_at = excluded.sent_at, window_start = excluded.window_start, window_count = excluded.window_count;

  return jsonb_build_object('ok', true, 'expires_in', greatest(30, least(p_ttl, 600)), 'resend_in', 60);
end $$;

-- بررسی کد؛ در صورت درست بودن کاربر ساخته (یا پیدا) می‌شود، نامش ذخیره می‌شود و نشست باز می‌شود
drop function if exists public.otp_verify(text, text, text);
create or replace function public.otp_verify(p_phone text, p_hash text, p_token_hash text, p_name text default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r auth_otps%rowtype;
  uid uuid;
  created boolean := false;
  nm text := nullif(btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g')), '');
  cur_name text;
begin
  if p_phone is null or p_phone !~ '^09[0-9]{9}$' or p_hash is null or p_token_hash is null or char_length(p_token_hash) < 32 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  if nm is not null and char_length(nm) not between 2 and 60 then
    return jsonb_build_object('ok', false, 'error', 'bad_name');
  end if;

  select * into r from auth_otps where phone = p_phone for update;
  if not found or r.expires_at < now() then
    return jsonb_build_object('ok', false, 'error', 'expired');
  end if;
  if r.attempts >= 5 then
    return jsonb_build_object('ok', false, 'error', 'locked');
  end if;

  if r.code_hash <> p_hash then
    update auth_otps set attempts = attempts + 1 where phone = p_phone;
    return jsonb_build_object('ok', false, 'error', 'wrong', 'attempts_left', greatest(0, 4 - r.attempts));
  end if;

  delete from auth_otps where phone = p_phone;
  select id, name into uid, cur_name from users where phone = p_phone;
  if uid is null then
    insert into users(phone, name) values (p_phone, nm) returning id into uid;
    cur_name := nm;
    created := true;
  elsif nm is not null and nm is distinct from cur_name then
    update users set name = nm where id = uid;
    cur_name := nm;
  end if;
  delete from user_sessions where user_id = uid and expires_at < now();
  insert into user_sessions(token_hash, user_id, expires_at) values (p_token_hash, uid, now() + interval '30 days');
  return jsonb_build_object('ok', true, 'phone', p_phone, 'name', cur_name, 'created', created);
end $$;

create or replace function public.session_phone(p_token_hash text)
returns text
language sql security definer set search_path = public stable as $$
  select u.phone from user_sessions s join users u on u.id = s.user_id
  where s.token_hash = p_token_hash and s.expires_at > now();
$$;

create or replace function public.session_info(p_token_hash text)
returns jsonb
language sql security definer set search_path = public stable as $$
  select jsonb_build_object('phone', u.phone, 'name', u.name) from user_sessions s join users u on u.id = s.user_id
  where s.token_hash = p_token_hash and s.expires_at > now();
$$;

create or replace function public.session_end(p_token_hash text)
returns void
language sql security definer set search_path = public as $$
  delete from user_sessions where token_hash = p_token_hash;
$$;

revoke all on function public.otp_issue(text,text,int) from public, anon, authenticated;
revoke all on function public.otp_verify(text,text,text,text) from public, anon, authenticated;
revoke all on function public.session_info(text) from public, anon, authenticated;
revoke all on function public.session_phone(text) from public, anon, authenticated;
revoke all on function public.session_end(text) from public, anon, authenticated;
grant execute on function public.otp_issue(text,text,int) to service_role;
grant execute on function public.otp_verify(text,text,text,text) to service_role;
grant execute on function public.session_info(text) to service_role;
grant execute on function public.session_phone(text) to service_role;
grant execute on function public.session_end(text) to service_role;


-- ============================================================
-- آزمون‌های هر حساب (روی شماره‌ی کاربر ذخیره می‌شوند، نه روی دستگاه)
-- کاربر با نشست خودش (token) شناخته می‌شود؛ فقط هش آن در جدول user_sessions است.
-- ============================================================
create table if not exists public.user_quizzes (
  user_id    uuid not null references public.users(id) on delete cascade,
  quiz_id    text not null references public.quizzes(id) on delete cascade,
  secret     text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, quiz_id)
);
alter table public.user_quizzes enable row level security;

-- شناسه‌ی کاربر از روی نشست (داخلی؛ از بیرون قابل‌فراخوانی نیست)
create or replace function public.session_uid(p_token text)
returns uuid
language sql security definer set search_path = public stable as $$
  select s.user_id from user_sessions s
  where p_token ~ '^[0-9a-f]{64}$'
    and s.token_hash = encode(sha256(convert_to(p_token, 'utf8')), 'hex')
    and s.expires_at > now();
$$;
revoke all on function public.session_uid(text) from public, anon, authenticated;

-- افزودن یک آزمون به حساب (فقط اگر کلید مدیریت درست باشد)
create or replace function public.account_claim(p_token text, p_id text, p_secret text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public.session_uid(p_token);
  if uid is null then return jsonb_build_object('ok', false, 'error', 'no_session'); end if;
  if p_id is null or p_secret is null or char_length(p_secret) < 16 or char_length(p_secret) > 128 then
    return jsonb_build_object('ok', false, 'error', 'bad_request');
  end if;
  if not exists (select 1 from quizzes where id = p_id) then
    return jsonb_build_object('ok', false, 'error', 'not_found');
  end if;
  if not exists (select 1 from quizzes where id = p_id and admin_hash = encode(sha256(convert_to(p_secret, 'utf8')), 'hex')) then
    return jsonb_build_object('ok', false, 'error', 'bad_secret');
  end if;
  insert into user_quizzes(user_id, quiz_id, secret) values (uid, p_id, p_secret)
  on conflict (user_id, quiz_id) do update set secret = excluded.secret;
  return jsonb_build_object('ok', true);
end $$;

-- فهرست آزمون‌های حساب
create or replace function public.account_quizzes(p_token text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid; items jsonb;
begin
  uid := public.session_uid(p_token);
  if uid is null then return jsonb_build_object('ok', false, 'error', 'no_session'); end if;
  select coalesce(jsonb_agg(x.j order by x.created_at desc), '[]'::jsonb) into items
  from (
    select uq.created_at,
           jsonb_build_object('id', q.id, 'secret', uq.secret, 'title', q.title, 'created_at', q.created_at,
                              'participants', (select count(*) from submissions s where s.quiz_id = q.id)) as j
    from user_quizzes uq join quizzes q on q.id = uq.quiz_id
    where uq.user_id = uid
    order by uq.created_at desc
    limit 200
  ) x;
  return jsonb_build_object('ok', true, 'items', items);
end $$;

revoke all on function public.account_claim(text,text,text) from public;
revoke all on function public.account_quizzes(text) from public;
grant execute on function public.account_claim(text,text,text) to anon, authenticated;
grant execute on function public.account_quizzes(text) to anon, authenticated;
