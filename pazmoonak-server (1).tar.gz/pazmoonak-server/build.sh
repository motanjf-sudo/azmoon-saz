#!/bin/sh
# تبدیل Edge Functionها از TypeScript به JavaScript (فقط روی کامپیوتر توسعه لازم است)
set -e
cd "$(dirname "$0")"
npx esbuild ../supabase/functions/auth-otp/index.ts --outfile=fn/auth-otp.js --format=cjs --platform=node --target=node18
npx esbuild ../supabase/functions/generate-quiz/index.ts --outfile=fn/node-api.js --format=cjs --platform=node --target=node18
