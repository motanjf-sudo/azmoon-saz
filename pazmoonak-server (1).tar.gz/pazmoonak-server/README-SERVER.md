# بک‌اند پازمونک روی سرور ایرانی

این بسته جای Supabase را می‌گیرد: دیتابیس PostgreSQL + API (آزمون‌ها، ورود با پیامک، ساخت آزمون با هوش مصنوعی).

## نصب (یک بار)
1. در DNS (لیارا) یک رکورد **A** بساز: نام `api` ← مقدار: IP سرور.
2. فایل `pazmoonak-server.tar.gz` را به سرور بفرست (روی کامپیوتر خودت، در پوشه‌ی فایل):
   `scp pazmoonak-server.tar.gz root@IP-SERVER:/root/`
3. به سرور وصل شو: `ssh root@IP-SERVER`
4. روی سرور:
   ```
   cd /root && tar xzf pazmoonak-server.tar.gz && cd pazmoonak-server
   bash install.sh api.pazmoonak.com
   ```
5. تست: `curl https://api.pazmoonak.com/healthz` باید `{"ok":true}` بدهد.

## تنظیم پیامک و هوش مصنوعی
`nano /etc/pazmoonak/env` را باز کن، مقدارها را پر کن (`SMS_PROVIDER=smsir`، `SMSIR_API_KEY`، `SMSIR_TEMPLATE_ID`، ...) و ذخیره کن (Ctrl+O، Enter، Ctrl+X). بعد: `systemctl restart pazmoonak`

## دستورهای مفید
- وضعیت: `systemctl status pazmoonak`
- لاگ: `journalctl -u pazmoonak -n 50`
- پشتیبان دستی: `/usr/local/bin/pazmoonak-backup.sh` (پشتیبان روزانه خودکار ساعت ۰۳:۳۰ در `/var/backups/pazmoonak`)
